// The font options every GatherSites editor offers (Matt, 2026-11-13: one curated set for all
// sites, wedding-industry clients only). The picker shows the site's current pairing first
// ("keep what I have"), then these five. Sites can't add or swap entries: a site's
// revision-config supplies only `currentFont`. Picks are requests, never live changes.
// Google `family=` values are what the picker loads into the preview frame.
import type { FontPair } from "./revision";

export const SHARED_FONTS: readonly FontPair[] = [
  {
    id: "fraunces-outfit",
    name: "Fraunces + Outfit",
    feel: "Warm, a little playful.",
    display: "'Fraunces', Georgia, serif",
    body: "'Outfit', system-ui, sans-serif",
    google: ["Fraunces:opsz,wght@9..144,400;9..144,600", "Outfit:wght@400;500"],
  },
  {
    id: "bricolage-outfit",
    name: "Bricolage Grotesque + Outfit",
    feel: "Modern, no serif.",
    display: "'Bricolage Grotesque', system-ui, sans-serif",
    body: "'Outfit', system-ui, sans-serif",
    google: ["Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600", "Outfit:wght@400;500"],
  },
  {
    id: "instrument-inter",
    name: "Instrument Serif + Inter",
    feel: "Clean, editorial.",
    display: "'Instrument Serif', Georgia, serif",
    body: "'Inter', system-ui, sans-serif",
    google: ["Instrument+Serif:ital@0;1", "Inter:wght@400;500"],
  },
  {
    id: "cormorant-outfit",
    name: "Cormorant Garamond + Outfit",
    feel: "Romantic, classic.",
    display: "'Cormorant Garamond', Georgia, serif",
    body: "'Outfit', system-ui, sans-serif",
    google: ["Cormorant+Garamond:wght@400;500;600", "Outfit:wght@400;500"],
  },
  {
    id: "jakarta",
    name: "Plus Jakarta Sans",
    feel: "Friendly, casual.",
    display: "'Plus Jakarta Sans', system-ui, sans-serif",
    body: "'Plus Jakarta Sans', system-ui, sans-serif",
    google: ["Plus+Jakarta+Sans:wght@400;500;700"],
  },
];

/** The picker's list: the site's current pairing (no override) first, then the shared five. */
export function fontOptions(current: { name: string; feel?: string }): FontPair[] {
  return [{ id: "current", name: current.name, feel: current.feel ?? "Your fonts now. No change." }, ...SHARED_FONTS];
}
