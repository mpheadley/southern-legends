import type { LucideIcon } from "lucide-react";

/** One editable line of text on the site. `path` is the dotted key stored in the CMS ("home.hero.title"). */
export type Field = {
  label: string;
  default: string;
  long?: boolean;
  /** Fields (and photos) sharing a group render as one mini-card in /edit ("Weddings", "Step 1"). */
  group?: string;
};

/** A group in the editor's left panel; usually one page section, top to bottom. */
export type Section = {
  title: string;
  /** id of the element on the page the preview scrolls to when this section opens. */
  anchor: string;
  fields: [path: string, field: Field][];
  /** Lucide icon shown in the section header. Defaults to Sparkles. */
  icon?: LucideIcon;
};

/** Proportions of the slot a photo lands in, so the editor's photo box shows the real shape. */
export type PhotoShape = { ratio: string; hint: string };

export type Photo = {
  /** CMS key; the override is stored at `images.<key>`. */
  key: string;
  label: string;
  /** Built-in file (the site's default). */
  src: string;
  /** Page anchor this photo sits in. Photos attach to the section with the same anchor unless `section` is set. */
  anchor: string;
  /** Name of a shape in `SiteConfig.shapes`. */
  shape: string;
  /** Section title this photo belongs to. Set it when two sections share an anchor. */
  section?: string;
  /** Mini-card this photo sits in, matching a `Field.group` in the same section. */
  group?: string;
};

/** Everything the editor needs to know about one site. The only per-site file is the one that builds this. */
export type SiteConfig = {
  /** Short id, same value as the CMS_SITE env var ("satco"). Used for storage keys and the attribution link. */
  slug: string;
  /** The business name ("Saturday Society Co."). */
  name: string;
  /** Welcome card headline; defaults to "Hey there." */
  greeting?: string;
  /** Plain line under the welcome card, e.g. "Stuck? Text Matt at (256) 644-7334." Omitted when unset. */
  help?: string;
  sections: Section[];
  photos: Photo[];
  shapes: Record<string, PhotoShape>;
  /** Where "See live site" and the preview iframe point. Defaults to "/". */
  liveUrl?: string;
};

/** The default copy for every field, keyed by path. Built from `sections`. */
export function textDefaults(sections: Section[]): Record<string, string> {
  return Object.fromEntries(sections.flatMap((s) => s.fields.map(([p, f]) => [p, f.default])));
}

/** Built-in file for a photo key ("" when unknown). */
export function photoSrc(photos: Photo[], key: string): string {
  return photos.find((p) => p.key === key)?.src ?? "";
}

/** Photos that belong to a section: an explicit `section` wins, else the shared anchor (minus photos claimed elsewhere). */
export function photosFor(section: Section, photos: Photo[]): Photo[] {
  return photos.filter((p) => (p.section ? p.section === section.title : p.anchor === section.anchor));
}

/** The undo-path a loaded (restored) version is recorded under. */
export const RESTORE_PATH = "__restore";

/**
 * Plain name for every editable path ("Cover: Headline", "Weddings: Line", "Cover photo"),
 * used to name what Undo will put back and what each published version changed.
 */
export function fieldNames(sections: Section[], photos: Photo[]): Record<string, string> {
  return {
    ...Object.fromEntries(sections.flatMap((s) => s.fields.map(([p, f]) => [p, `${f.group ?? s.title}: ${f.label}`]))),
    ...Object.fromEntries(photos.map((p) => [`images.${p.key}`, p.label])),
    [RESTORE_PATH]: "Loaded version",
  };
}
