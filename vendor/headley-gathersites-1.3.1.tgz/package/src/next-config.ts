import type { NextConfig } from "next";

const PKG = "@headley/gathersites";
const BLOB_PATTERN = { protocol: "https" as const, hostname: "*.public.blob.vercel-storage.com" };
const FRAME_HEADER = { key: "X-Frame-Options", value: "SAMEORIGIN" };

/**
 * Wraps a site's next.config so the editor works:
 * - transpiles this package (it ships TypeScript source),
 * - allows Vercel Blob photos in next/image,
 * - sets X-Frame-Options: SAMEORIGIN on every route so /edit can show the site in its preview
 *   iframe (a site's own headers() still runs; a later SAMEORIGIN rule wins over an earlier DENY).
 */
export function withGatherSites(config: NextConfig = {}): NextConfig {
  const transpile = new Set(config.transpilePackages ?? []);
  transpile.add(PKG);
  const patterns = [...(config.images?.remotePatterns ?? [])];
  if (!patterns.some((p) => p.hostname === BLOB_PATTERN.hostname)) patterns.push(BLOB_PATTERN);
  const userHeaders = config.headers;
  return {
    ...config,
    transpilePackages: [...transpile],
    images: { ...config.images, remotePatterns: patterns },
    async headers() {
      const own = userHeaders ? await userHeaders() : [];
      return [...own, { source: "/(.*)", headers: [FRAME_HEADER] }];
    },
  };
}
