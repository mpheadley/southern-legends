// GatherSites revision requests: save + tell Matt. A request never changes the site.
// Three delivery paths, each best-effort; the request counts as delivered if any one lands:
//   1. Turso `site_revision_requests` (migration: packages/gathersites/migrations/2026-11-11_site_revision_requests.sql,
//      NOT run yet; until it is, the insert fails quietly and email + feed still go out)
//   2. Owner email via Resend (same pattern as the starter kit's forms/submit route)
//   3. Gather Feed card (same endpoint + secret header as packages/shared/src/feed.ts)
//
// Env var NAMES (values live in Vercel/.env.local, never in code):
//   TURSO_DATABASE_URL, TURSO_AUTH_TOKEN, CMS_SITE, RESEND_API_KEY, CMS_NOTIFY_EMAIL,
//   RESEND_FROM, FEED_INGEST_SECRET, GATHER_FEED_URL (optional)
import "server-only";
import type { RevisionPayload } from "../revision";

export type RevisionRecord = RevisionPayload & { site: string; createdAt: string };

const LIMITS: Record<string, number> = { name: 80, font: 120, colors: 120, what: 2000, where: 120, why: 2000, priority: 40 };

/** Keep only known string fields, trimmed and capped. */
export function cleanPayload(body: Record<string, unknown>): RevisionPayload | null {
  const kind = body.kind === "look" || body.kind === "change" ? body.kind : null;
  if (!kind) return null;
  const out: RevisionPayload = { kind };
  for (const [k, max] of Object.entries(LIMITS)) {
    const v = body[k];
    if (typeof v === "string" && v.trim()) (out as Record<string, string>)[k] = v.trim().slice(0, max);
  }
  if (kind === "change" && (!out.what || out.what.length < 3)) return null;
  if (kind === "look" && !out.font && !out.colors) return null;
  return out;
}

export function summarize(r: RevisionRecord): { title: string; lines: [string, string][] } {
  const who = r.name ? ` from ${r.name}` : "";
  if (r.kind === "look") {
    return {
      title: `Look pick${who}: ${r.font ?? "same fonts"} · ${r.colors ?? "same colors"}`,
      lines: [["Fonts", r.font ?? "—"], ["Colors", r.colors ?? "—"], ["Note", r.why ?? "—"]],
    };
  }
  return {
    title: `Change request${who}${r.priority ? ` (${r.priority})` : ""}: ${(r.what ?? "").slice(0, 70)}`,
    lines: [["What", r.what ?? "—"], ["Where", r.where ?? "—"], ["Why", r.why ?? "—"], ["How much it matters", r.priority ?? "—"], ["Name", r.name ?? "—"]],
  };
}

async function saveRequest(r: RevisionRecord): Promise<boolean> {
  const url = process.env.TURSO_DATABASE_URL || "";
  const token = process.env.TURSO_AUTH_TOKEN || "";
  if (!url || !token) return false;
  const args = [r.site, r.kind, JSON.stringify(r), "new", r.createdAt].map((value) => ({ type: "text", value }));
  const res = await fetch(url.replace("libsql://", "https://") + "/v2/pipeline", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      requests: [
        { type: "execute", stmt: { sql: "INSERT INTO site_revision_requests (site, kind, payload, status, created_at) VALUES (?, ?, ?, ?, ?)", args } },
        { type: "close" },
      ],
    }),
    cache: "no-store",
  });
  if (!res.ok) return false;
  const j = await res.json().catch(() => null);
  return j?.results?.[0]?.type === "ok"; // a missing table comes back as type "error"
}

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] || c);

async function emailOwner(r: RevisionRecord): Promise<boolean> {
  const key = process.env.RESEND_API_KEY;
  const to = process.env.CMS_NOTIFY_EMAIL;
  if (!key || !to) return false;
  const { title, lines } = summarize(r);
  const rows = lines.map(([k, v]) => `<tr><td style="padding:8px 14px;color:#4f5d55;font-weight:600;vertical-align:top">${esc(k)}</td><td style="padding:8px 14px;white-space:pre-wrap">${esc(v)}</td></tr>`).join("");
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      // Resend's edge blocks some default server user agents (403 1010).
      "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    },
    body: JSON.stringify({
      from: process.env.RESEND_FROM || "GatherSites <onboarding@resend.dev>",
      to: [to],
      subject: `[GatherSites · ${r.site}] ${title}`,
      html: `<div style="font:16px/1.5 system-ui,Arial;color:#1E3A2F"><h2 style="font-family:Georgia,serif;font-weight:500">${esc(title)}</h2><table style="border-collapse:collapse">${rows}</table><p style="color:#4f5d55;font-size:14px">Sent from the GatherSites editor on ${esc(r.site)}. Nothing changed on the live site. Review it and apply by hand.</p></div>`,
    }),
  });
  return res.ok;
}

async function pushFeed(r: RevisionRecord): Promise<boolean> {
  const secret = process.env.FEED_INGEST_SECRET;
  if (!secret) return false;
  const { title, lines } = summarize(r);
  const res = await fetch(process.env.GATHER_FEED_URL || "https://app.gatherstudio.app/api/feed", {
    method: "POST",
    headers: { "content-type": "application/json", "x-feed-secret": secret },
    body: JSON.stringify({
      ts: r.createdAt,
      type: "content",
      venture: "gather-marketing",
      platform: "web",
      title: `${r.site}: ${title}`,
      tldr: "Client revision request from GatherSites. Review it, then apply by hand.",
      bullets: lines.filter(([, v]) => v !== "—").map(([k, v]) => `${k}: ${v.slice(0, 200)}`),
      actions: [{ text: `Review and apply the ${r.kind === "look" ? "look pick" : "change"} for ${r.site}` }],
      source: "gathersites-revision",
    }),
  });
  return res.ok;
}

/** Deliver a request every way that's configured. Returns which paths landed. */
export async function deliverRevision(r: RevisionRecord): Promise<{ saved: boolean; emailed: boolean; feed: boolean }> {
  const [saved, emailed, feed] = await Promise.all([
    saveRequest(r).catch(() => false),
    emailOwner(r).catch(() => false),
    pushFeed(r).catch(() => false),
  ]);
  return { saved, emailed, feed };
}
