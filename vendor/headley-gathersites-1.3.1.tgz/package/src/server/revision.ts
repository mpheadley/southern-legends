// app/api/revision/route.ts in a site:
//   export { POST } from "@headley/gathersites/server/revision";
//   export const dynamic = "force-dynamic";
//
// POST /api/revision { editKey, kind: "look" | "change", ...fields }
// Logged-in editors only (same CMS_EDIT_KEY as publish). Saves + notifies Matt.
// It never touches site content: a human reviews and applies every request.
import { NextResponse } from "next/server";
import { siteSlug, verifyEditKey } from "./cms-db";
import { cleanPayload, deliverRevision } from "./revision-deliver";

export function createRevisionHandler(opts: { site?: string } = {}) {
  async function POST(req: Request) {
    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Bad request." }, { status: 400 });
    }
    if (!verifyEditKey(body?.editKey)) {
      await new Promise((r) => setTimeout(r, 800)); // slow down guessing
      return NextResponse.json({ error: "That password isn't right." }, { status: 403 });
    }
    const payload = cleanPayload(body);
    if (!payload) return NextResponse.json({ error: "Tell Matt what you'd like changed first." }, { status: 400 });

    const result = await deliverRevision({ ...payload, site: siteSlug(opts.site), createdAt: new Date().toISOString() });
    if (!result.saved && !result.emailed && !result.feed) {
      // Nothing configured or everything down: say so, so the client doesn't think it went through.
      return NextResponse.json({ error: "That didn't send.", ...result }, { status: 502 });
    }
    return NextResponse.json({ ok: true, ...result });
  }
  return { POST };
}

export const { POST } = createRevisionHandler();
