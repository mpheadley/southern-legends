// app/api/cms/versions/route.ts in a site:
//   export { POST } from "@headley/gathersites/server/versions";
//   export const dynamic = "force-dynamic";
import { NextResponse } from "next/server";
import { listVersions, siteSlug, verifyEditKey } from "./cms-db";

// POST { editKey } → the last 30 published versions, newest first (owner-gated).
export function createVersionsHandler(opts: { site?: string } = {}) {
  async function POST(req: Request) {
    try {
      const { editKey } = await req.json();
      if (!verifyEditKey(editKey)) return NextResponse.json({ error: "That password isn't right." }, { status: 403 });
      return NextResponse.json({ versions: await listVersions(siteSlug(opts.site)) });
    } catch (e) {
      return NextResponse.json({ error: String(e) }, { status: 500 });
    }
  }
  return { POST };
}

export const { POST } = createVersionsHandler();
