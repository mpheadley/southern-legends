// app/api/cms/route.ts in a site:
//   export { GET, POST } from "@headley/gathersites/server/cms";
//   export const dynamic = "force-dynamic";
import { NextResponse } from "next/server";
import { getContent, saveContent, saveVersion, siteSlug, verifyEditKey } from "./cms-db";

const MAX_BYTES = 200_000;

// Best-effort: email the owner a copy of every publish, if CMS_NOTIFY_EMAIL is set.
// Never blocks or fails the save — a missed notification isn't worth a failed publish.
async function notify(site: string, content: Record<string, unknown>) {
  const key = process.env.RESEND_API_KEY?.trim();
  const to = process.env.CMS_NOTIFY_EMAIL?.trim();
  const from = process.env.CMS_NOTIFY_FROM?.trim();
  if (!key || !to || !from) return;
  const summary = Object.keys(content).join(", ") || "(content)";
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: [to],
        subject: `${site} edited`,
        text: `A change was just published on ${site}.\n\nSections touched: ${summary}\n\n${JSON.stringify(content, null, 2).slice(0, 4000)}`,
      }),
    });
  } catch {
    /* notification only */
  }
}

export function createCmsHandlers(opts: { site?: string } = {}) {
  // GET /api/cms → published content overrides (everyone sees them).
  async function GET() {
    try {
      return NextResponse.json({ content: await getContent(siteSlug(opts.site)) });
    } catch (e) {
      return NextResponse.json({ content: {}, error: String(e) }, { status: 200 });
    }
  }

  // POST /api/cms { editKey, check? } → password check only.
  // POST /api/cms { editKey, content } → publish (owner-gated).
  async function POST(req: Request) {
    try {
      const body = await req.json();
      if (!verifyEditKey(body?.editKey)) {
        await new Promise((r) => setTimeout(r, 800)); // slow down guessing
        return NextResponse.json({ error: "That password isn't right." }, { status: 403 });
      }
      if (body.check) return NextResponse.json({ ok: true });
      const content = body.content;
      if (!content || typeof content !== "object" || Array.isArray(content))
        return NextResponse.json({ error: "Nothing to publish." }, { status: 400 });
      if (JSON.stringify(content).length > MAX_BYTES)
        return NextResponse.json({ error: "Too much content to save at once." }, { status: 413 });
      const site = siteSlug(opts.site);
      await saveContent(site, content);
      await saveVersion(site, content);
      notify(site, content).catch(() => {});
      return NextResponse.json({ ok: true });
    } catch (e) {
      return NextResponse.json({ error: String(e) }, { status: 500 });
    }
  }

  return { GET, POST };
}

export const { GET, POST } = createCmsHandlers();
