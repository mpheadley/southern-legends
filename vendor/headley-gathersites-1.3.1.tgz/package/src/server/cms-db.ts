// GatherSites CMS persistence: the shared Turso `site_cms` table (one row per site) and
// `site_cms_versions` (last 30 publishes). The only writer is the site owner publishing
// from /edit, behind CMS_EDIT_KEY.
//
// Env var NAMES (values live in Vercel / .env.local, never in code):
//   TURSO_DATABASE_URL, TURSO_AUTH_TOKEN, CMS_SITE, CMS_EDIT_KEY, BLOB_READ_WRITE_TOKEN
//   CMS_TURSO_DATABASE_URL / CMS_TURSO_AUTH_TOKEN override the plain pair above —
//   for a site whose TURSO_DATABASE_URL already points at its own app DB (e.g. one
//   logging site_events elsewhere) and can't be repointed to the CMS's database.
import "server-only";
import crypto from "crypto";

type Val = { type: string; value?: string };

async function run(sql: string, args: string[] = []) {
  const url = process.env.CMS_TURSO_DATABASE_URL || process.env.TURSO_DATABASE_URL || "";
  const token = process.env.CMS_TURSO_AUTH_TOKEN || process.env.TURSO_AUTH_TOKEN || "";
  if (!url || !token) return null; // not configured locally: behave as "no overrides"
  const res = await fetch(url.replace("libsql://", "https://") + "/v2/pipeline", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      requests: [
        { type: "execute", stmt: { sql, args: args.map((a) => ({ type: "text", value: a })) } },
        { type: "close" },
      ],
    }),
    cache: "no-store",
  });
  if (!res.ok) throw new Error("Turso error " + res.status);
  return res.json();
}

/** The site's row key. CMS_SITE env, else the value a route factory was given. Throws when neither is set. */
export function siteSlug(fallback?: string): string {
  const s = process.env.CMS_SITE || fallback || "";
  if (!s) throw new Error("CMS_SITE is not set");
  return s;
}

/** Published content overrides for a site ({} if none, or if Turso isn't configured). */
export async function getContent(site: string): Promise<Record<string, unknown>> {
  const j = await run("SELECT content FROM site_cms WHERE site = ?", [site]);
  const rows = j?.results?.[0]?.response?.result?.rows;
  if (!rows || !rows.length) return {};
  try {
    return JSON.parse((rows[0][0] as Val).value || "{}");
  } catch {
    return {};
  }
}

export async function saveContent(site: string, content: Record<string, unknown>): Promise<void> {
  const j = await run(
    `INSERT INTO site_cms (site, content, updated_at) VALUES (?, ?, ?)
     ON CONFLICT(site) DO UPDATE SET content = excluded.content, updated_at = excluded.updated_at`,
    [site, JSON.stringify(content), new Date().toISOString()],
  );
  if (!j) throw new Error("Turso not configured");
}

// Published-version history: one row per publish, last 30 kept.
// Best-effort: if the table doesn't exist yet, publishing still works and history is empty.
const KEEP = 30;

export async function saveVersion(site: string, content: Record<string, unknown>): Promise<void> {
  try {
    await run("INSERT INTO site_cms_versions (site, content, published_at) VALUES (?, ?, ?)", [site, JSON.stringify(content), new Date().toISOString()]);
    await run(
      `DELETE FROM site_cms_versions WHERE site = ? AND id NOT IN
       (SELECT id FROM site_cms_versions WHERE site = ? ORDER BY id DESC LIMIT ${KEEP})`,
      [site, site],
    );
  } catch {
    /* history is optional */
  }
}

export async function listVersions(site: string): Promise<{ id: number; publishedAt: string; content: Record<string, unknown> }[]> {
  try {
    const j = await run("SELECT id, published_at, content FROM site_cms_versions WHERE site = ? ORDER BY id DESC LIMIT " + KEEP, [site]);
    const rows = (j?.results?.[0]?.response?.result?.rows ?? []) as Val[][];
    return rows.map((r) => {
      let content: Record<string, unknown> = {};
      try { content = JSON.parse(r[2].value || "{}"); } catch {}
      return { id: Number(r[0].value), publishedAt: r[1].value || "", content };
    });
  } catch {
    return [];
  }
}

/** True only if pw matches CMS_EDIT_KEY (timing-safe). No key set → nobody can edit. */
export function verifyEditKey(pw: unknown): boolean {
  const key = process.env.CMS_EDIT_KEY || "";
  if (!key || typeof pw !== "string") return false;
  const a = crypto.createHash("sha256").update(pw.trim()).digest();
  const b = crypto.createHash("sha256").update(key).digest();
  return crypto.timingSafeEqual(a, b);
}
