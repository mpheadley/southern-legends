// app/api/cms/upload/route.ts in a site:
//   export { POST } from "@headley/gathersites/server/upload";
//   export const dynamic = "force-dynamic";
import { NextResponse } from "next/server";
import { put } from "@vercel/blob";
import { siteSlug, verifyEditKey } from "./cms-db";

// POST { dataUrl, editKey } → stores the photo in Vercel Blob, returns its public URL.
// Image bytes never go in Turso. SVG is refused (it can carry script).
const TYPES: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };

export function createUploadHandler(opts: { site?: string } = {}) {
  async function POST(req: Request) {
    try {
      const { dataUrl, editKey } = await req.json();
      if (!verifyEditKey(editKey)) return NextResponse.json({ error: "That password isn't right." }, { status: 403 });
      const m = typeof dataUrl === "string" ? dataUrl.match(/^data:(image\/[a-z]+);base64,(.+)$/) : null;
      if (!m || !TYPES[m[1]]) return NextResponse.json({ error: "Please use a JPG, PNG or WebP photo." }, { status: 400 });
      const [, mime, b64] = m;
      if (b64.length > 4_000_000) return NextResponse.json({ error: "That photo is too large." }, { status: 413 });
      const site = siteSlug(opts.site);
      const blob = await put(`cms/${site}/${Date.now().toString(36)}.${TYPES[mime]}`, Buffer.from(b64, "base64"), {
        access: "public",
        contentType: mime,
        addRandomSuffix: true,
      });
      return NextResponse.json({ url: blob.url });
    } catch (e) {
      return NextResponse.json({ error: String(e) }, { status: 500 });
    }
  }
  return { POST };
}

export const { POST } = createUploadHandler();
