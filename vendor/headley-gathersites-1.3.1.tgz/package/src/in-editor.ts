/** True inside /edit or its live-preview iframe. Sites use it to mute tracking, popups and smooth-scroll there. */
export function inEditor(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return window.self !== window.top || window.location.pathname.startsWith("/edit");
  } catch {
    return true;
  }
}
