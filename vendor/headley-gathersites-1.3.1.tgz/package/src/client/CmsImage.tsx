"use client";

import Image from "next/image";
import type { CSSProperties, ReactNode } from "react";
import { useCms } from "./Cms";

/**
 * A photo the owner can replace from /edit. Shows the published override if there is one,
 * otherwise the built-in file. `note` (a photo credit, say) renders only while the
 * built-in photo is showing. Always `fill`; the parent sets the box.
 */
export function CmsImage({
  imgKey,
  src,
  alt,
  sizes,
  priority,
  style,
  note,
}: {
  imgKey: string;
  src: string;
  alt: string;
  sizes: string;
  priority?: boolean;
  style?: CSSProperties;
  note?: ReactNode;
}) {
  const { get } = useCms();
  const override = get(`images.${imgKey}`);
  const replaced = typeof override === "string" && override.length > 0;
  return (
    <>
      <Image src={replaced ? override : src} alt={alt} fill priority={priority} sizes={sizes} style={style} data-cms-path={`images.${imgKey}`} />
      {!replaced && note}
    </>
  );
}
