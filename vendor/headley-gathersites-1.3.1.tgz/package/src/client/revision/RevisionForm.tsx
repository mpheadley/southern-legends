"use client";

// One-page change checklist: what, where, why, how much it matters. One submit.
// It never edits the site; it sends a request Matt reviews and applies by hand.
import { useState } from "react";
import { Check, Send } from "lucide-react";
import { PRIORITIES, sendRevision, type RevisionSiteConfig } from "../../revision";

const EMPTY = { name: "", what: "", where: "", why: "", priority: "" };

export default function RevisionForm({ config, editKey, onRelock }: { config: RevisionSiteConfig; editKey: string; onRelock?: () => void }) {
  const [v, setV] = useState(EMPTY);
  const [err, setErr] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "sent">("idle");
  const set = (k: keyof typeof EMPTY) => (e: { target: { value: string } }) => { setV((o) => ({ ...o, [k]: e.target.value })); if (err) setErr(""); };

  async function submit() {
    if (v.what.trim().length < 3) return setErr("Tell Matt what you'd like changed first.");
    setState("sending");
    const r = await sendRevision(editKey, {
      kind: "change",
      name: v.name.trim() || undefined,
      what: v.what.trim(),
      where: v.where || undefined,
      why: v.why.trim() || undefined,
      priority: v.priority || undefined,
    });
    if (r.status === 403) { setState("idle"); return onRelock?.(); }
    if (!r.ok) { setState("idle"); return setErr("That didn't send. Your words are still here. Check your internet and try again."); }
    setState("sent");
    setV(EMPTY);
  }

  if (state === "sent") {
    return (
      <div className="rv">
        <p className="rv-done" role="status">
          <Check size={22} strokeWidth={2.25} aria-hidden /> Sent to Matt. He reads every request and makes the change himself. Nothing on your live site changes until he does.
        </p>
        <button type="button" className="btn ghost" onClick={() => setState("idle")}>Ask for another change</button>
      </div>
    );
  }

  return (
    <form className="rv" onSubmit={(e) => { e.preventDefault(); submit(); }} noValidate>
      <p className="rv-note">Bring this list to your review call, or send it now. One change per request works best.</p>

      <label className="edit-field">
        <span className="edit-label">1. What would you like changed?</span>
        <textarea rows={4} value={v.what} onChange={set("what")} aria-invalid={!!err && v.what.trim().length < 3} aria-describedby={err ? "rv-form-err" : undefined} placeholder="Example: Swap the cover photo for one from the Smith wedding." required />
      </label>

      <label className="edit-field">
        <span className="edit-label">2. Where on the site?</span>
        <select className="rv-select" value={v.where} onChange={set("where")}>
          <option value="">Pick a spot (optional)</option>
          {config.places.map((p) => <option key={p} value={p}>{p}</option>)}
        </select>
      </label>

      <label className="edit-field">
        <span className="edit-label">3. Why? (optional)</span>
        <textarea rows={3} value={v.why} onChange={set("why")} placeholder="Example: That photo shows our new style better." />
      </label>

      <fieldset className="rv-group">
        <legend className="edit-label">4. How much does it matter?</legend>
        <div className="rv-seg" role="radiogroup" aria-label="How much does it matter?">
          {PRIORITIES.map((p) => (
            <label key={p} className={`rv-seg-opt${v.priority === p ? " is-on" : ""}`}>
              <input type="radio" name="rv-priority" value={p} checked={v.priority === p} onChange={set("priority")} />
              {p}
            </label>
          ))}
        </div>
      </fieldset>

      <label className="edit-field">
        <span className="edit-label">Your name (optional)</span>
        <input value={v.name} onChange={set("name")} placeholder={config.clientNames.split(/\s*\+\s*/)[0]} autoComplete="given-name" />
      </label>

      <button type="submit" className="btn rv-send" disabled={state === "sending"}>
        <Send size={18} strokeWidth={1.75} aria-hidden /> {state === "sending" ? "Sending…" : "Send to Matt"}
      </button>
      {err && <p className="edit-inline-err" id="rv-form-err" role="alert">{err}</p>}
    </form>
  );
}
