"use client";

// Locked-feature teaser. Which tiles are open comes from the site's config (tier + extras),
// never hand-coded per tile. Locked ones are grayed out with a lock and a "See plans" link.
// No prices here; the pricing page owns them.
import { ArrowUpRight, Check, ClipboardList, FilePlus2, Lock, Mail, NotebookPen, Sparkles, Star, TrendingUp, type LucideIcon } from "lucide-react";
import { PREMIUM_FEATURES, PRICING_URL, isUnlocked, type PremiumFeature, type RevisionSiteConfig } from "../../revision";

const ICONS: Record<string, LucideIcon> = {
  reviews: Star,
  forms: ClipboardList,
  pages: FilePlus2,
  blog: NotebookPen,
  newsletter: Mail,
  stats: TrendingUp,
};

export default function FeatureTeaser({ config, features = PREMIUM_FEATURES }: { config: RevisionSiteConfig; features?: PremiumFeature[] }) {
  const href = `${PRICING_URL}?utm_source=gathersites&utm_medium=editor&utm_campaign=${encodeURIComponent(config.site)}-locked-feature`;
  const sorted = [...features].sort((a, b) => Number(isUnlocked(b, config.tier, config.extras)) - Number(isUnlocked(a, config.tier, config.extras)));
  return (
    <div className="rv">
      <p className="rv-note">Want your site to do more? These can be added. Matt sets each one up for you.</p>
      <ul className="rv-tiles">
        {sorted.map((f) => {
          const open = isUnlocked(f, config.tier, config.extras);
          const Icon = ICONS[f.id] ?? Sparkles;
          return (
            <li key={f.id} className={`rv-tile${open ? " is-open" : " is-locked"}`}>
              <span className="rv-tile-icon" aria-hidden><Icon size={26} strokeWidth={1.6} /></span>
              <span className="rv-tile-text">
                <span className="rv-tile-name">
                  {!open && <Lock className="rv-lock" size={18} strokeWidth={2} aria-hidden />}
                  {f.name}
                  {!open && <span className="rv-sr"> (locked)</span>}
                </span>
                <span className="rv-tile-line">{f.line}</span>
                {open ? (
                  <span className="rv-tile-status"><Check size={18} strokeWidth={2.25} aria-hidden /> In your plan. Ask Matt to turn it on.</span>
                ) : (
                  <a className="rv-tile-link" href={href} target="_blank" rel="noopener noreferrer">
                    See plans <ArrowUpRight size={18} strokeWidth={2} aria-hidden /><span className="rv-sr"> for {f.name} (opens in a new tab)</span>
                  </a>
                )}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
