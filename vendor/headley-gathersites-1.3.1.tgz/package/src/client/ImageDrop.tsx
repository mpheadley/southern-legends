"use client";

import { useRef, useState } from "react";
import { AlertCircle, ImageUp, RotateCcw } from "lucide-react";

// Photo drop box: drag-drop or click. Shrinks the photo in the browser (longest side
// 2000px, JPEG) so phone photos upload fast, then hands back a data URL.
async function shrink(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = url;
    });
    const scale = Math.min(1, 2000 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement("canvas");
    c.width = Math.round(img.naturalWidth * scale);
    c.height = Math.round(img.naturalHeight * scale);
    c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.85);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function ImageDrop({
  label,
  current,
  onUpload,
  ratio = "4 / 5",
  hint = "Tall",
  progress = null,
  error = "",
  onRetry,
}: {
  label: string;
  current: string;
  onUpload: (dataUrl: string) => void;
  /** CSS aspect-ratio of the slot on the page; the box takes the same proportions. */
  ratio?: string;
  /** Short word shown in the box corner ("Wide", "Tall"). */
  hint?: string;
  /** 0–100 while uploading, null when idle. */
  progress?: number | null;
  /** Plain-words error shown inside the box; empty when fine. */
  error?: string;
  /** Called by the in-box "Try again" when the last upload failed. */
  onRetry?: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const [openErr, setOpenErr] = useState("");
  const busy = progress !== null;
  const err = error || openErr;

  async function handle(file?: File | null) {
    if (!file || busy) return;
    setOpenErr("");
    try {
      onUpload(await shrink(file));
    } catch {
      setOpenErr("Couldn't open that photo. Try a JPG or PNG.");
    }
  }

  function pick() {
    if (busy) return;
    if (inputRef.current) inputRef.current.value = "";
    inputRef.current?.click();
  }

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`Replace photo: ${label}`}
      aria-busy={busy}
      onClick={pick}
      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } }}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); handle(e.dataTransfer.files?.[0]); }}
      className={`edit-drop${over ? " over" : ""}${err ? " has-error" : ""}`}
      style={{ aspectRatio: ratio }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      {current && <img src={current} alt="" />}
      <span className="edit-drop-hint" aria-hidden>{hint}</span>
      {!err && (
        <span className="edit-drop-btn">
          <ImageUp size={18} strokeWidth={1.75} aria-hidden /> {busy ? "Uploading…" : "Replace"}
        </span>
      )}
      {busy && (
        <span className="edit-drop-bar" role="progressbar" aria-label="Uploading" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress ?? 0}>
          <i style={{ width: `${Math.max(4, progress ?? 0)}%` }} />
        </span>
      )}
      {err && (
        <span className="edit-drop-err" role="alert">
          <AlertCircle size={20} strokeWidth={1.75} aria-hidden />
          <span>{err}</span>
          <button
            type="button"
            className="btn ghost"
            onClick={(e) => { e.stopPropagation(); if (error && onRetry) onRetry(); else { setOpenErr(""); pick(); } }}
          >
            <RotateCcw size={16} strokeWidth={1.75} aria-hidden /> Try again
          </button>
        </span>
      )}
      <input ref={inputRef} type="file" accept="image/*" hidden onChange={(e) => handle(e.target.files?.[0])} />
    </div>
  );
}
