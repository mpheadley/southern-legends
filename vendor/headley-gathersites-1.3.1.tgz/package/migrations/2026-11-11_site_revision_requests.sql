-- GatherSites revision requests (font/color picks + change checklist submissions).
-- Target: the shared Turso DB that already holds site_cms / site_cms_versions.
-- NOT RUN. Needs Matt's "WRITE TO TURSO" before anyone applies it.
-- Until it runs, /api/revision still emails Matt and posts to the Gather Feed;
-- only the saved row is skipped.
--
-- Apply (after the go):
--   turso db shell <db-name> < packages/gathersites/migrations/2026-11-11_site_revision_requests.sql

CREATE TABLE IF NOT EXISTS site_revision_requests (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  site       TEXT NOT NULL,                 -- CMS_SITE slug, e.g. 'satco'
  kind       TEXT NOT NULL,                 -- 'look' | 'change'
  payload    TEXT NOT NULL,                 -- JSON: the cleaned request fields
  status     TEXT NOT NULL DEFAULT 'new',   -- 'new' | 'doing' | 'done' | 'declined'
  created_at TEXT NOT NULL,                 -- ISO timestamp
  done_at    TEXT,
  notes      TEXT                           -- Matt's notes when he applies it
);

CREATE INDEX IF NOT EXISTS idx_site_revision_requests_site ON site_revision_requests (site, created_at DESC);
