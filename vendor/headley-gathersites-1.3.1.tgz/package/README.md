# @headley/gathersites

GatherSites v1: the `/edit` screen a client uses to change the words and photos on their own site. One shared workspace package instead of a copy per site, so a fix lands everywhere at the next deploy. First site on it: Saturday Society Co. (`apps/satco-site`).

What the owner gets: a password-locked editor with sections, photo boxes (phone photos resized in the browser), a live preview, step Undo, Discard all, Publish, and the last 30 published versions with one-click restore. Nothing is public until Publish. Editor chrome is Gather Marketing's brand; the client's site keeps its own.

## Layout

```
packages/gathersites/
  src/index.ts          types, textDefaults/photoSrc/photosFor, inEditor, EDIT_METADATA   (no "use client")
  src/client/           CmsProvider, useCms, Editable, T, CmsImage, ImageDrop, EditorPage, GatherSitesMark
  src/server/           cms-db (Turso), cms / upload / versions route handlers (+ factories)
  src/next-config.ts    withGatherSites()
  styles.css            editor chrome on --gm-* tokens; its own fonts (Fraunces, Courier Prime, Inter)
  assets/               mark-forest.svg, mark-cream.svg (the mark is also inlined as <GatherSitesMark/>)
  test/editor.mjs       Playwright run-through, works against any site on the package
```

## Install on a site (about 40 lines in 7 files)

1. **Dependency.** In the app's `package.json`: `"@headley/gathersites": "workspace:*"`, then `pnpm install` from the monorepo root. The app must deploy from the root (see "Deploying").

2. **next.config.ts**
   ```ts
   import { withGatherSites } from "@headley/gathersites/next-config";
   export default withGatherSites({ /* the site's config */ });
   ```
   Adds `transpilePackages`, the Blob image host, and `X-Frame-Options: SAMEORIGIN` (the preview iframe). Drop any `DENY` the site had.

3. **API routes** (2 lines each)
   ```ts
   // app/api/cms/route.ts
   export { GET, POST } from "@headley/gathersites/server/cms";
   export const dynamic = "force-dynamic";
   // app/api/cms/upload/route.ts
   export { POST } from "@headley/gathersites/server/upload";
   export const dynamic = "force-dynamic";
   // app/api/cms/versions/route.ts
   export { POST } from "@headley/gathersites/server/versions";
   export const dynamic = "force-dynamic";
   ```
   The handlers read `CMS_SITE` from the env. A site that would rather pin it: `export const { GET, POST } = createCmsHandlers({ site: "slug" })`.

4. **Editor route**
   ```tsx
   // app/edit/layout.tsx
   import { EDIT_METADATA } from "@headley/gathersites";
   import "@headley/gathersites/styles.css";
   export const metadata = EDIT_METADATA;
   export default function EditLayout({ children }: { children: React.ReactNode }) { return children; }

   // app/edit/page.tsx
   "use client";
   import { EditorPage } from "@headley/gathersites/client";
   import { EDITOR } from "@/lib/content";
   export default function Edit() { return <EditorPage config={EDITOR} />; }
   ```

5. **`src/lib/content.ts`** — the only per-site file. Build a `SiteConfig`:
   ```ts
   import { textDefaults, type SiteConfig, type Section, type Photo } from "@headley/gathersites";
   export const SECTIONS: Section[] = [{ title: "Cover", anchor: "top", icon: ImageIcon, fields: [["home.hero.title", { label: "Headline", default: "…" }]] }];
   export const PHOTOS: Photo[] = [{ key: "cover", label: "Cover photo", src: "/images/hero.webp", anchor: "top", shape: "wide" }];
   export const PHOTO_SHAPES = { wide: { ratio: "16 / 9", hint: "Wide" }, tall: { ratio: "4 / 5", hint: "Tall" } };
   export const TEXT_DEFAULTS = textDefaults(SECTIONS);
   export const EDITOR: SiteConfig = { slug: "satco", name: "Saturday Society Co.", greeting: "Hey Hollie + Claire.", help: "Stuck? Text Matt at (256) 644-7334.", sections: SECTIONS, photos: PHOTOS, shapes: PHOTO_SHAPES };
   ```
   `slug` = the `CMS_SITE` value. Photos attach to the section with the same `anchor`; when two sections share an anchor, set `section: "<title>"` on the photo. The tour opens the first section that has both a photo and text.

6. **Wire the page.** Root layout: `<CmsProvider defaults={TEXT_DEFAULTS}>…</CmsProvider>` (from `@headley/gathersites/client`). Text: `<T k="home.hero.title" as="h1" />`. Photos: `<CmsImage imgKey="cover" src={photoSrc("cover")} alt="…" sizes="100vw" />` inside a positioned box (it renders `fill`). Mute tracking/popups in the editor with `inEditor()`.
   Migrating a site that already had the copy-in editor: pass `storageKey="ssContent"` (its old key) to `CmsProvider` so unpublished drafts in the owner's browser survive.

7. **Env vars** (names only; values live in Vercel / `.env.local`, never in code):
   `TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN` (gather-shared DB, tables `site_cms` + `site_cms_versions`, already exist), `CMS_SITE` (the row key), `CMS_EDIT_KEY` (the owner's password, set with `vercel env add CMS_EDIT_KEY production --sensitive`), `BLOB_READ_WRITE_TOKEN` (photos).
   Blob: create a store once and link it to the project with `POST https://api.vercel.com/v1/storage/stores/{storeId}/connections` `{ "projectId": "prj_…", "envVarEnvironments": ["production","preview","development"] }` (the CLI's link prompt can't be answered non-interactively). Linking writes `BLOB_READ_WRITE_TOKEN` into the project's env.

## Revision tools (optional, since 1.1.0)

Three more sections under the content sections: **Fonts + colors** (previews live inside the preview frame only, then "Send my pick"), **Ask for a change** (one form, one submit) and **More features** (grayed-out tiles that link to the pricing page; no prices here). None of them change the site. Every submit is a request Matt applies by hand. Scope rule (Matt, 2026-11-11): clients edit words and photos; fonts, colors and layout are requests.

1. `src/lib/revision-config.ts` builds a `RevisionSiteConfig`: `site`, `clientNames`, `tier` (a `gs.tiers[].id` from `studio-offer.json`; omit on sites that aren't on that ladder), `extras`, `currentFont` (`{ name, feel? }` = the site's fonts today, shown first as "keep what I have"; the other five options are `SHARED_FONTS` in `src/fonts.ts`, the same on every site and not overridable), `looks` (accent colors, AA-checked), `places`, `cssVars` (the site's CSS variables the preview overrides), `showUpgrades` (default true; `false` hides the tiles).
2. `app/edit/page.tsx`: `<EditorPage config={EDITOR} revision={REVISION} />`. Leave `revision` off and nothing changes.
3. `app/api/revision/route.ts`: `export { POST } from "@headley/gathersites/server/revision"; export const dynamic = "force-dynamic";`
4. Env (names only): `CMS_NOTIFY_EMAIL`, `RESEND_API_KEY`, `RESEND_FROM` (owner email), `FEED_INGEST_SECRET`, `GATHER_FEED_URL` (optional). Turso row needs `migrations/2026-11-11_site_revision_requests.sql` applied (gated: `WRITE TO TURSO`); until then the insert fails quietly and email + feed still go out. If no path lands, the client sees "That didn't send."

## Deploying

The package is TypeScript source resolved through the pnpm workspace, so a site **must build from the monorepo root**. `vercel --prod` run inside `apps/<site>` uploads only that folder; its install then fails with `npm error EUNSUPPORTEDPROTOCOL Unsupported URL Type "workspace:"` (proved locally 2026-10-26). Per site, once: Vercel project `rootDirectory = apps/<site>`, install `pnpm install --no-frozen-lockfile`, build `pnpm run build`, ignore command `git diff HEAD^ HEAD --quiet -- apps/<site> packages/gathersites` (exit 0 = skip). Then deploy from `gather/` with `VERCEL_PROJECT_ID=… VERCEL_ORG_ID=… vercel --prod`, local `pnpm --filter <site> build` first, `DEPLOY <SITE> TO VERCEL` gate.

## Security model

- One shared password per site (`CMS_EDIT_KEY`), checked timing-safe on every write and on the versions read; a wrong key waits 800 ms. No key set → nobody can edit. The editor keeps it in `sessionStorage` for the tab only; a 403 relocks the screen.
- `GET /api/cms` is public (it is what visitors render). Writes: content ≤ 200 KB, must be a JSON object; photos ≤ ~3 MB base64, JPG/PNG/WebP only, SVG refused (script), stored in Vercel Blob under `cms/<site>/`, never in Turso.
- Drafts live in the owner's browser (`localStorage`); only the editor's Publish button publishes. `Editable` never publishes on its own (the copy-in version auto-published on blur when a key was held; that is gone).
- The site is shown inside the editor through a same-origin iframe, so `X-Frame-Options` is `SAMEORIGIN`, not `DENY`.
- Blast radius: a package change reaches a site only when that site redeploys. Bump `version` and note it in each site's commit.

## Package test

Before any change to the package, run it against a site on a throwaway key:

```sh
printf 'CMS_EDIT_KEY=localtest\nCMS_SITE=satco\n' > apps/satco-site/.env.local
env -u BLOB_READ_WRITE_TOKEN -u TURSO_DATABASE_URL -u TURSO_AUTH_TOKEN pnpm --filter satco-site exec next start -p 3050
cd <a folder with playwright installed> && node /path/to/packages/gathersites/test/editor.mjs --url http://localhost:3050 --key localtest --shots ./shots
rm apps/satco-site/.env.local
```

Unlock → tour offer → 5 tour steps + pointing hand → exit → edit (chip, section dot, pulsing Publish) → undo → discard all → wheel-scroll the panel → history panel renders → `Editable` has no publish call → log out. It never publishes; Turso and Blob are never written.
