// @headley/gathersites — shared, framework-level pieces (no "use client" here, so server
// files such as app/edit/layout.tsx can import values from this entry).
export type { Field, Section, Photo, PhotoShape, SiteConfig } from "./types";
export { textDefaults, photoSrc, photosFor, fieldNames, RESTORE_PATH } from "./types";
export { inEditor } from "./in-editor";
export type { RevisionSiteConfig, FontPair, LookOption, PremiumFeature, TierId, RevisionKind, RevisionPayload } from "./revision";
export { TIER_ORDER, PREMIUM_FEATURES, PRICING_URL, PRIORITIES, isUnlocked } from "./revision";
export { FONT_CATALOG, fontPair } from "./fonts";

/** Metadata for the /edit route: `export const metadata = EDIT_METADATA` in app/edit/layout.tsx. */
export const EDIT_METADATA = {
  title: "GatherSites · Edit your site",
  robots: { index: false, follow: false },
} as const;
