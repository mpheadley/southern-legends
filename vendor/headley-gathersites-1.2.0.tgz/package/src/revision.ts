// GatherSites revision tools: shared types + the premium-feature catalog.
// Part of @headley/gathersites since 2026-11-12 (first built on apps/satco-site, ffea81a11a).
// Each site supplies a RevisionSiteConfig in its src/lib/revision-config.ts.
//
// Scope rule (Matt, 2026-11-11): a human reviews and applies every change.
// Nothing here publishes. The picker only previews; every submit becomes a request.

/** Plan ids match `gs.tiers[].id` in gather/packages/brand/studio-offer.json, lowest first. */
export const TIER_ORDER = ["get-found", "get-calls", "get-booked", "get-growing", "get-dominant"] as const;
export type TierId = (typeof TIER_ORDER)[number];

export const PRICING_URL = "https://gathermarketing.co/website-pricing";

export type FontPair = {
  id: string;
  name: string;
  /** Short plain-words feel, shown under the name. */
  feel: string;
  /** CSS font-family for headlines. Omit on the site's current pairing (no override). */
  display?: string;
  /** CSS font-family for body text. Omit to keep the site's body font. */
  body?: string;
  /** Google Fonts `family=` values to load for the preview (e.g. "Marcellus"). */
  google?: string[];
};

export type LookOption = {
  id: string;
  name: string;
  feel: string;
  /** Omit all colors on the site's current look (no override). */
  accent?: string;      // buttons + highlights, light mode (AA with accentText)
  accentHover?: string;
  accentDark?: string;  // accent in dark mode (AA on the dark background)
  swatch: string[];     // 2–3 colors for the chip
};

export type PremiumFeature = {
  id: string;
  name: string;
  line: string;
  /** Lowest plan that includes it. Omit for add-ons that only unlock via `extras`. */
  from?: TierId;
};

/**
 * Which plan unlocks which feature. [VERIFY with Matt] This is a packaging decision,
 * set here once for every site; no prices live in this file.
 */
export const PREMIUM_FEATURES: PremiumFeature[] = [
  { id: "reviews", name: "Google reviews wall", line: "Your best reviews on your site, kept fresh.", from: "get-booked" },
  { id: "forms", name: "Booking + inquiry forms", line: "Custom forms that land in your inbox.", from: "get-booked" },
  { id: "pages", name: "More pages", line: "Add a page for a new service, event or offer." },
  { id: "blog", name: "Blog editor", line: "Write posts. Matt checks each one before it goes live.", from: "get-growing" },
  { id: "newsletter", name: "Newsletter signup", line: "Collect emails and send a monthly note.", from: "get-growing" },
  { id: "stats", name: "Visitor numbers", line: "See how many people visit and what they tap.", from: "get-dominant" },
];

export type RevisionSiteConfig = {
  /** Site slug, sent with every request. */
  site: string;
  /** Who uses the editor ("Hollie + Claire"). */
  clientNames: string;
  /** Plan from the site's agreement. Drives the locked tiles. Omit when the site isn't on the GS ladder (e.g. church sites). */
  tier?: TierId;
  /** Show the "More features" locked tiles. Default true. Set false for sites with no tier mapping. */
  showUpgrades?: boolean;
  /** Feature ids unlocked on top of the plan (paid add-ons). */
  extras?: string[];
  fonts: FontPair[];
  looks: LookOption[];
  /** "Where on the site?" choices for the change form. */
  places: string[];
  /** The site's CSS variables the picker overrides inside the preview frame only. */
  cssVars: { display: string[]; body: string[]; accent: string[]; accentHover?: string[] };
};

export type RevisionKind = "look" | "change";

export type RevisionPayload = {
  kind: RevisionKind;
  name?: string;
  // look
  font?: string;
  colors?: string;
  // change
  what?: string;
  where?: string;
  why?: string;
  priority?: string;
};

export const PRIORITIES = ["Must have", "Would be nice", "Someday"] as const;

export function isUnlocked(f: PremiumFeature, tier: TierId | undefined, extras: string[] = []): boolean {
  if (extras.includes(f.id)) return true;
  if (!f.from || !tier) return false;
  return TIER_ORDER.indexOf(tier) >= TIER_ORDER.indexOf(f.from);
}

/** Send a request to the site's /api/revision. Resolves with a plain-words result. */
export async function sendRevision(editKey: string, payload: RevisionPayload): Promise<{ ok: boolean; status: number; error?: string }> {
  try {
    const r = await fetch("/api/revision", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ editKey, ...payload }),
    });
    const j = await r.json().catch(() => ({}));
    return { ok: r.ok, status: r.status, error: j?.error };
  } catch {
    return { ok: false, status: 0 };
  }
}
