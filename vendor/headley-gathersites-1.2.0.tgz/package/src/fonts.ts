// Brand-safe font pairings the fonts + colors picker can offer. ONE home for the menu;
// each site picks ids in its revision-config.ts (and may add its own inline pairs).
// Source: nextjs-starter-kit/font-picker-template.html (the 15 Google families Matt vetted,
// 2026-09-11) plus the condensed trio named in FBC-WEAVER-BUILD.md. Google `family=` values
// are what the picker loads into the preview frame. Nothing here applies to a live site.
import type { FontPair } from "./revision";

export const FONT_CATALOG: Record<string, FontPair> = {
  cormorant: { id: "cormorant", name: "Cormorant Garamond + Outfit", feel: "Romantic, editorial.", display: "'Cormorant Garamond', Georgia, serif", google: ["Cormorant+Garamond:wght@400;500;600"] },
  marcellus: { id: "marcellus", name: "Marcellus + Jost", feel: "Elegant caps, clean body.", display: "'Marcellus', Georgia, serif", body: "'Jost', system-ui, sans-serif", google: ["Marcellus", "Jost:wght@400;500"] },
  playfair: { id: "playfair", name: "Playfair Display + Inter", feel: "Bold magazine look.", display: "'Playfair Display', Georgia, serif", body: "'Inter', system-ui, sans-serif", google: ["Playfair+Display:wght@400;500", "Inter:wght@400;500"] },
  gilda: { id: "gilda", name: "Gilda Display + Outfit", feel: "Light and delicate.", display: "'Gilda Display', Georgia, serif", google: ["Gilda+Display"] },
  cinzel: { id: "cinzel", name: "Cinzel + Josefin Sans", feel: "Carved, formal.", display: "'Cinzel', Georgia, serif", body: "'Josefin Sans', system-ui, sans-serif", google: ["Cinzel:wght@400;500", "Josefin+Sans:wght@300;400;500"] },
  tenor: { id: "tenor", name: "Tenor Sans + Inter", feel: "Quiet, modern.", display: "'Tenor Sans', system-ui, sans-serif", body: "'Inter', system-ui, sans-serif", google: ["Tenor+Sans", "Inter:wght@400;500"] },
  italiana: { id: "italiana", name: "Italiana + Montserrat", feel: "Thin, high fashion.", display: "'Italiana', Georgia, serif", body: "'Montserrat', system-ui, sans-serif", google: ["Italiana", "Montserrat:wght@300;400"] },
  fraunces: { id: "fraunces", name: "Fraunces + Inter", feel: "Warm, friendly serif.", display: "'Fraunces', Georgia, serif", body: "'Inter', system-ui, sans-serif", google: ["Fraunces:ital,opsz,wght@0,9..144,400;1,9..144,400", "Inter:wght@400;500"] },
  bodoni: { id: "bodoni", name: "Bodoni Moda + Montserrat", feel: "Sharp, classic contrast.", display: "'Bodoni Moda', Georgia, serif", body: "'Montserrat', system-ui, sans-serif", google: ["Bodoni+Moda:wght@400;500", "Montserrat:wght@300;400"] },
  // Condensed display options (churches, events, sports-feel brands).
  anton: { id: "anton", name: "Anton + Inter", feel: "Heavy, poster-bold.", display: "'Anton', 'Arial Narrow', sans-serif", body: "'Inter', system-ui, sans-serif", google: ["Anton", "Inter:wght@400;500"] },
  bebas: { id: "bebas", name: "Bebas Neue + Inter", feel: "Tall caps, clean.", display: "'Bebas Neue', 'Arial Narrow', sans-serif", body: "'Inter', system-ui, sans-serif", google: ["Bebas+Neue", "Inter:wght@400;500"] },
  oswald: { id: "oswald", name: "Oswald + Inter", feel: "Condensed, steady.", display: "'Oswald', 'Arial Narrow', sans-serif", body: "'Inter', system-ui, sans-serif", google: ["Oswald:wght@500;600", "Inter:wght@400;500"] },
  antonDm: { id: "antonDm", name: "Anton + DM Sans", feel: "Bold heads, rounder body.", display: "'Anton', 'Arial Narrow', sans-serif", body: "'DM Sans', system-ui, sans-serif", google: ["Anton", "DM+Sans:wght@400;500"] },
};

/** A catalog pairing by id, or undefined. Use in a site's revision-config: `fontPair("marcellus")!`. */
export function fontPair(id: keyof typeof FONT_CATALOG | string): FontPair | undefined {
  return FONT_CATALOG[id];
}
