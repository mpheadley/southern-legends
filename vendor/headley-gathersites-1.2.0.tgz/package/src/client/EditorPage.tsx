"use client";

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import {
  Check,
  ChevronDown,
  Eye,
  ExternalLink,
  History,
  RotateCcw,
  Lock,
  LogOut,
  MessageSquarePlus,
  MoreHorizontal,
  Palette,
  PenLine,
  Route,
  Trash2,
  Sparkles,
  Undo2,
  UploadCloud,
} from "lucide-react";
import { useCms } from "./Cms";
import { ImageDrop } from "./ImageDrop";
import { GatherSitesMark } from "./Mark";
import { runEditorTour } from "./tour";
import LookPicker from "./revision/LookPicker";
import RevisionForm from "./revision/RevisionForm";
import FeatureTeaser from "./revision/FeatureTeaser";
import { fieldNames, photosFor, RESTORE_PATH, type Photo, type Section, type SiteConfig } from "../types";
import type { RevisionSiteConfig } from "../revision";

const PHONE = "(max-width: 860px)";
const isPhone = () => typeof window !== "undefined" && window.matchMedia(PHONE).matches;

const PLAIN_ERROR = "That didn't save. Your changes are still here. Check your internet and try again.";
const PHOTO_ERROR = "That photo didn't upload. Check your internet and try again.";

type Confirm = { title: string; body: string; yes: string; no: string; onYes: () => void };

type Toast = { msg: string; kind: "ok" | "err" | "busy"; retry?: () => void; action?: { label: string; run: () => void } };
type Version = { id: number; publishedAt: string; content: Record<string, unknown> };

/** Upload with real progress (fetch can't report upload progress). Resolves with the HTTP status + JSON body. */
function uploadWithProgress(dataUrl: string, editKey: string, onProgress: (pct: number) => void) {
  return new Promise<{ status: number; body: { url?: string; error?: string } }>((resolve) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/cms/upload");
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
    xhr.onload = () => {
      let body = {};
      try { body = JSON.parse(xhr.responseText); } catch {}
      resolve({ status: xhr.status, body });
    };
    xhr.onerror = () => resolve({ status: 0, body: {} });
    xhr.send(JSON.stringify({ dataUrl, editKey }));
  });
}

/**
 * The whole /edit screen: password unlock, welcome + tour, sections with photo boxes and
 * fields, live preview, published versions, phone bottom bar. Render it from a site's
 * app/edit/page.tsx ("use client") with that site's config. Needs CmsProvider above it
 * (the site's root layout) and "@headley/gathersites/styles.css" loaded once.
 *
 * `revision` (optional) adds the revision tools under the content sections: a fonts + colors
 * preview, an "Ask for a change" form and, unless `revision.showUpgrades === false`, the
 * locked-feature tiles. None of them change the site; every submit is a request Matt applies.
 */
export function EditorPage({ config, revision }: { config: SiteConfig; revision?: RevisionSiteConfig }) {
  const { sections, photos, shapes } = config;
  const liveUrl = config.liveUrl || "/";
  const PW_KEY = `${config.slug}-edit-key`;
  const TOUR_KEY = `${config.slug}-edit-tour-done`;
  // The tour's "cover" section: the first one with both a photo and some text; opens by default.
  const tourSection = sections.find((s) => photosFor(s, photos).length > 0 && s.fields.length > 0) ?? sections[0];
  const FIELD_NAMES = fieldNames(sections, photos);
  const allPaths = Object.keys(FIELD_NAMES).filter((p) => p !== RESTORE_PATH);

  const { get, defaults, setField, setImage, publish, reset, undo, canUndo, undoPath, replaceAll, dirty, isDirty } = useCms();
  const [key, setKey] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [pwError, setPwError] = useState("");
  const [toast, setToast] = useState<Toast | null>(null);
  const [busy, setBusy] = useState(false);
  const [offerTour, setOfferTour] = useState(false);
  const [tab, setTab] = useState<"edit" | "preview">("edit");
  const [progress, setProgress] = useState<Record<string, number>>({});
  const [photoErr, setPhotoErr] = useState<Record<string, string>>({});
  const lastPhoto = useRef<Record<string, { anchor: string; dataUrl: string }>>({});
  const preview = useRef<HTMLIFrameElement>(null);
  const getFrame = useCallback(() => preview.current, []);
  const [versions, setVersions] = useState<Version[] | null>(null);
  const [versionsError, setVersionsError] = useState(false);
  const [confirm, setConfirm] = useState<Confirm | null>(null);

  // Short feedback next to the action (under the header on desktop, above the bottom bar on phones).
  const toastTimer = useRef<number | null>(null);
  function say(msg: string, kind: Toast["kind"] = "ok", extra: Partial<Toast> = {}) {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ msg, kind, ...extra });
    if (kind === "ok") toastTimer.current = window.setTimeout(() => setToast(null), 4000);
  }
  const previewAction = () => (isPhone() ? { action: { label: "Preview", run: () => { setTab("preview"); setToast(null); } } } : {});

  // Server said the password is wrong (e.g. it was changed): lock the editor and ask again.
  function relock() {
    try { sessionStorage.removeItem(PW_KEY); } catch {}
    setUnlocked(false);
    setKey("");
    setToast(null);
    setPwError("Your password changed. Type the new one. Your changes are still saved in this browser.");
  }

  async function loadVersions(pw = key) {
    const r = await fetch("/api/cms/versions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ editKey: pw }) }).catch(() => null);
    const j = r ? await r.json().catch(() => ({})) : {};
    if (r?.status === 403) return relock();
    setVersionsError(!r?.ok);
    setVersions(r?.ok && Array.isArray(j.versions) ? j.versions : []);
  }

  function restore(content: Record<string, unknown>, label: string) {
    setConfirm({
      title: `Load ${label}?`,
      body: "It replaces what's in the editor now. Your live site won't change until you Publish, and Undo brings your current version back.",
      no: "Keep what I have",
      yes: "Load it",
      onYes: () => {
        replaceAll(content);
        say(`Loaded ${label}. Check the preview, then Publish.`, "ok", previewAction());
        scrollTo(sections[0]?.anchor ?? "top");
      },
    });
  }

  useEffect(() => {
    try {
      const saved = sessionStorage.getItem(PW_KEY);
      if (saved) { setKey(saved); setUnlocked(true); loadVersions(saved); }
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const hasDraft = dirty;
  const changedPaths = [
    ...sections.flatMap((s) => s.fields.map(([p]) => p)),
    ...photos.map((p) => `images.${p.key}`),
  ].filter((p) => isDirty(p));
  const changeCount = changedPaths.length;
  const sectionChanged = (s: Section) =>
    s.fields.some(([p]) => isDirty(p)) || photosFor(s, photos).some((p) => isDirty(`images.${p.key}`));

  function scrollTo(anchor: string) {
    try {
      preview.current?.contentWindow?.document.getElementById(anchor)?.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch {}
  }

  async function unlock() {
    if (!key.trim()) return setPwError("Type your password.");
    setBusy(true);
    setPwError("");
    const r = await fetch("/api/cms", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ editKey: key, check: true }) }).catch(() => null);
    setBusy(false);
    if (!r) return setPwError("Couldn't reach the site. Check your internet and try again.");
    if (!r.ok) return setPwError("That password isn't right.");
    try { sessionStorage.setItem(PW_KEY, key); } catch {}
    setUnlocked(true);
    setTab("edit");
    loadVersions();
    let seen = false;
    try { seen = localStorage.getItem(TOUR_KEY) === "1"; } catch {}
    setOfferTour(!seen);
  }

  function startTour() {
    setOfferTour(false);
    setTab("edit");
    setTimeout(() => runEditorTour(TOUR_KEY), 250);
  }
  function skipTour() {
    setOfferTour(false);
    try { localStorage.setItem(TOUR_KEY, "1"); } catch {}
  }

  function logout() {
    if (hasDraft) {
      return setConfirm({
        title: "Log out?",
        body: "You have changes that aren't live yet. They stay saved on this device, so they'll be here when you log back in.",
        no: "Stay logged in",
        yes: "Log out",
        onYes: endSession,
      });
    }
    endSession();
  }
  function endSession() {
    try { sessionStorage.removeItem(PW_KEY); } catch {}
    setKey("");
    setUnlocked(false);
    setVersions(null);
    setOfferTour(false);
    setPwError("");
    say(dirty ? "Logged out. Your unpublished changes are still on this device." : "Logged out.");
  }

  async function onPhoto(k: string, anchor: string, dataUrl: string) {
    lastPhoto.current[k] = { anchor, dataUrl };
    setPhotoErr((e) => ({ ...e, [k]: "" }));
    setProgress((p) => ({ ...p, [k]: 0 }));
    const { status, body } = await uploadWithProgress(dataUrl, key, (pct) => setProgress((p) => ({ ...p, [k]: pct })));
    setProgress((p) => { const n = { ...p }; delete n[k]; return n; });
    if (status === 403) return relock();
    if (status < 200 || status >= 300) {
      return setPhotoErr((e) => ({ ...e, [k]: (status === 400 || status === 413) && body.error ? body.error : PHOTO_ERROR }));
    }
    setImage(k, body.url || "");
    say("Photo added. Check the preview, then Publish.", "ok", previewAction());
    setTimeout(() => scrollTo(anchor), 300);
  }

  // The one and only place content goes live.
  async function doPublish() {
    setBusy(true);
    say("Publishing…", "busy");
    const r = await publish(key);
    setBusy(false);
    if (!r.ok && /password/i.test(r.error || "")) return relock();
    if (!r.ok) return say(PLAIN_ERROR, "err", { retry: doPublish });
    say("Live now.", "ok", { action: { label: "See it", run: () => window.open(liveUrl, "_blank", "noopener") } });
    loadVersions();
  }

  const undoName = undoPath ? FIELD_NAMES[undoPath] ?? "last change" : "";
  function doUndo() { const n = undoName; undo(); say(`Undid ${n || "your last change"}.`); }
  function doDiscard() {
    setConfirm({
      title: `Throw away ${changeCount === 1 ? "1 change" : `all ${changeCount} changes`}?`,
      body: "Everything you haven't published goes back to what's live now. Your live site won't change.",
      no: "Keep my changes",
      yes: "Throw them away",
      onYes: () => { reset(); say("All unpublished changes discarded."); },
    });
  }

  const text = (p: string) => {
    const v = get(p);
    return typeof v === "string" ? v : defaults[p] ?? "";
  };
  const photo = (k: string, fallback: string) => {
    const v = get(`images.${k}`);
    return typeof v === "string" && v ? v : fallback;
  };
  const replaced = (k: string) => {
    const v = get(`images.${k}`);
    return typeof v === "string" && v.length > 0;
  };
  const shapeOf = (name: string) => shapes[name] ?? { ratio: "4 / 5", hint: "Tall" };

  // One section open at a time; the opened one moves to the top of the panel.
  function onSection(el: HTMLDetailsElement, anchor?: string) {
    if (!el.open) return;
    document.querySelectorAll<HTMLDetailsElement>(".edit-sec[open]").forEach((d) => { if (d !== el) d.open = false; });
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    requestAnimationFrame(() => el.scrollIntoView({ block: "start", behavior: reduce ? "auto" : "smooth" }));
    if (anchor) scrollTo(anchor);
  }

  const photoGrid = (list: Photo[], inCard = false) => list.length > 0 && (
    <div className="edit-grid">
      {list.map((p) => (
        <div key={p.key} className={`edit-photo edit-photo-${p.shape}`}>
          <p className="edit-label">{inCard ? "Photo" : p.label}</p>
          <ImageDrop
            label={p.label}
            current={photo(p.key, p.src)}
            ratio={shapeOf(p.shape).ratio}
            hint={shapeOf(p.shape).hint}
            progress={p.key in progress ? progress[p.key] : null}
            error={photoErr[p.key] || ""}
            onRetry={() => { const l = lastPhoto.current[p.key]; if (l) onPhoto(p.key, l.anchor, l.dataUrl); }}
            onUpload={(d) => onPhoto(p.key, p.anchor, d)}
          />
          {replaced(p.key) && (
            <button type="button" className="edit-mini" onClick={() => { setImage(p.key, ""); say("Original photo back. Publish to keep it."); }}>Use the original</button>
          )}
        </div>
      ))}
    </div>
  );

  const fieldRow = ([path, f]: Section["fields"][number]) => (
    <label key={path} className={`edit-field${isDirty(path) ? " changed" : ""}`}>
      <span className="edit-label">{f.label}</span>
      {f.long ? (
        <textarea rows={3} value={text(path)} onChange={(e) => setField(path, e.target.value)} />
      ) : (
        <input value={text(path)} onChange={(e) => setField(path, e.target.value)} />
      )}
    </label>
  );

  /** Name what a published version changed compared with the one before it ("Cover: Headline, Cover photo"). */
  function whatChanged(c: Record<string, unknown>, before: Record<string, unknown>): string {
    const at = (o: Record<string, unknown>, path: string) => {
      const v = path.split(".").reduce<unknown>((a, k) => (a && typeof a === "object" ? (a as Record<string, unknown>)[k] : undefined), o);
      return typeof v === "string" ? v : "";
    };
    const names = allPaths.filter((p) => at(c, p) !== at(before, p)).map((p) => FIELD_NAMES[p]);
    if (!names.length) return "Same as the one before";
    return names.length <= 3 ? names.join(", ") : `${names.slice(0, 2).join(", ")} and ${names.length - 2} more`;
  }

  const chip = changeCount > 0
    ? <span className="edit-chip" role="status">{changeCount} change{changeCount === 1 ? "" : "s"} not live yet</span>
    : <span className="edit-chip quiet" role="status"><Check size={16} strokeWidth={2} aria-hidden /> Everything&apos;s live</span>;
  const publishBtn = (
    <button className={`btn${hasDraft ? " edit-pulse" : ""}`} type="button" data-tour="publish" onClick={doPublish} disabled={busy || !hasDraft}>
      <UploadCloud size={18} strokeWidth={1.75} aria-hidden /> Publish
    </button>
  );
  // Undo + Discard sit inline on desktop and in the "…" menu on phones; the rest always lives in the menu.
  const undoDiscard: ReactNode = (
    <>
      <button className="btn ghost" type="button" data-tour="undo" disabled={busy || !canUndo} onClick={doUndo} title={undoName ? `Undo ${undoName}` : undefined}><Undo2 size={18} strokeWidth={1.75} aria-hidden /> <span className="edit-undo-label">Undo{undoName && <> · {undoName}</>}</span></button>
      <button className="btn ghost" type="button" data-tour="discard" disabled={busy || !hasDraft} onClick={doDiscard}><Trash2 size={18} strokeWidth={1.75} aria-hidden /> Discard all</button>
    </>
  );
  const menuRest: ReactNode = (
    <>
      <button className="btn ghost" type="button" data-tour="help" onClick={startTour}><Route size={18} strokeWidth={1.75} aria-hidden /> Show me around</button>
      <a className="btn ghost" href={liveUrl} target="_blank" rel="noopener noreferrer"><ExternalLink size={18} strokeWidth={1.75} aria-hidden /> See live site</a>
      <button className="btn ghost" type="button" onClick={logout}><LogOut size={18} strokeWidth={1.75} aria-hidden /> Log out</button>
    </>
  );

  return (
    <div className="edit-shell" data-tab={tab} data-unlocked={unlocked ? "1" : "0"}>
      <header className="edit-bar">
        <span className="edit-lockup" aria-label="GatherSites">
          <GatherSitesMark size={30} />
          <span className="edit-word">GatherSites</span>
        </span>
        {unlocked && (
          <>
            <div className="edit-row edit-desktop-actions">
              {chip}
              {publishBtn}
              {undoDiscard}
            </div>
            <details className="edit-more">
              <summary aria-label="More actions"><MoreHorizontal size={26} strokeWidth={1.75} aria-hidden /></summary>
              <div className="edit-more-menu" onClick={(e) => (e.currentTarget.parentElement as HTMLDetailsElement).open = false}>
                <span className="edit-more-phone">{undoDiscard}</span>
                {menuRest}
              </div>
            </details>
          </>
        )}
        {!unlocked && <a className="edit-link" href={liveUrl} target="_blank" rel="noopener noreferrer">See live site <ExternalLink size={16} strokeWidth={1.75} aria-hidden /></a>}
        <a className="edit-brand" href={`https://gatherstudio.app/?utm_source=gathersites&utm_medium=editor&utm_campaign=${encodeURIComponent(config.slug)}`} target="_blank" rel="noopener noreferrer">
          <span>by Gather Marketing — Matt Headley</span>
        </a>
      </header>

      <div className="edit-body">
        <aside className="edit-panel">
          {!unlocked ? (
            <form className="edit-welcome" onSubmit={(e) => { e.preventDefault(); unlock(); }}>
              <Lock size={40} strokeWidth={1.5} aria-hidden className="edit-welcome-icon" />
              <h1>{config.greeting || "Hey there."}</h1>
              <p>Type your password to change the words and photos on your site. Nothing goes live until you hit Publish.</p>
              <input className="edit-input" type="password" value={key} onChange={(e) => { setKey(e.target.value); if (pwError) setPwError(""); }} placeholder="Password" autoComplete="current-password" aria-label="Password" aria-invalid={!!pwError} aria-describedby={pwError ? "edit-pw-error" : undefined} />
              <button className="btn" type="submit" disabled={busy}><Lock size={18} strokeWidth={1.75} aria-hidden /> Unlock</button>
              {pwError && <p className="edit-inline-err" id="edit-pw-error" role="alert">{pwError}</p>}
              {config.help && <p className="edit-help-line">{config.help}</p>}
            </form>
          ) : (
            <>
              {offerTour && (
                <div className="edit-welcome edit-offer" role="region" aria-label="Welcome">
                  <Route size={40} strokeWidth={1.5} aria-hidden className="edit-welcome-icon" />
                  <h1>You&apos;re in.</h1>
                  <p>Want a 60-second tour? Five quick stops: sections, photos, words, preview, publish.</p>
                  <div className="edit-row">
                    <button className="btn" type="button" onClick={startTour}><Route size={18} strokeWidth={1.75} aria-hidden /> Take the tour</button>
                    <button className="btn ghost" type="button" onClick={skipTour}>Skip, I&apos;ll explore</button>
                  </div>
                </div>
              )}
              <div data-tour="sections">
            {sections.map((s) => {
              const Icon = s.icon ?? Sparkles;
              const secPhotos = photosFor(s, photos);
              const changed = sectionChanged(s);
              const isTour = s === tourSection;
              return (
                <details key={s.title} data-tour={isTour ? "cover" : undefined} className="edit-sec" open={isTour} onToggle={(e) => onSection(e.currentTarget, s.anchor)}>
                  <summary>
                    <Icon size={22} strokeWidth={1.75} aria-hidden />
                    <span className="edit-sec-title">
                      {s.title}
                      {changed && <i className="edit-dot" role="img" aria-label="Has changes not live yet" />}
                    </span>
                    <span className="edit-sec-count">
                      {secPhotos.length > 0 && `${secPhotos.length} photo${secPhotos.length > 1 ? "s" : ""}, `}
                      {s.fields.length} line{s.fields.length === 1 ? "" : "s"}
                    </span>
                    <ChevronDown size={20} strokeWidth={1.75} className="edit-chev" aria-hidden />
                  </summary>
                  <div className="edit-sec-body">
                    {/* Loose photos + fields first, then one mini-card per group (each event type, each step). */}
                    {photoGrid(secPhotos.filter((p) => !p.group))}
                    {s.fields.filter(([, f]) => !f.group).map(fieldRow)}
                    {[...new Set(s.fields.map(([, f]) => f.group).filter((g): g is string => !!g))].map((g) => {
                      const gPhotos = secPhotos.filter((p) => p.group === g);
                      const gFields = s.fields.filter(([, f]) => f.group === g);
                      const gChanged = gFields.some(([p]) => isDirty(p)) || gPhotos.some((p) => isDirty(`images.${p.key}`));
                      return (
                        <fieldset key={g} className={`edit-card${gPhotos.length ? " has-photo" : ""}`}>
                          <legend>{g}{gChanged && <i className="edit-dot" role="img" aria-label="Has changes not live yet" />}</legend>
                          {photoGrid(gPhotos, true)}
                          <div className="edit-card-fields">{gFields.map(fieldRow)}</div>
                        </fieldset>
                      );
                    })}
                  </div>
                </details>
              );
            })}
            <details className="edit-sec" data-tour="history" onToggle={(e) => onSection(e.currentTarget)}>
              <summary>
                <History size={22} strokeWidth={1.75} aria-hidden />
                <span className="edit-sec-title">Published versions</span>
                <span className="edit-sec-count">{versionsError ? "Couldn't load" : versions ? `${versions.length} saved` : ""}</span>
                <ChevronDown size={20} strokeWidth={1.75} className="edit-chev" aria-hidden />
              </summary>
              <div className="edit-sec-body">
                {versionsError && (
                  <p className="edit-help edit-help-err">
                    Your saved versions didn&apos;t load. <button type="button" className="edit-mini" onClick={() => loadVersions()}>Try again</button>
                  </p>
                )}
                <p className="edit-help">Every time you publish, a copy is saved here (the last 30). Load any one to bring it back, check the preview, then Publish.</p>
                <ul className="edit-versions">
                  {(versions ?? []).map((v, i) => (
                    <li key={v.id}>
                      <span>
                        <strong>{fmt(v.publishedAt)}{i === 0 && <span className="edit-live-pill">Live now</span>}</strong>
                        <span className="edit-sec-count">{whatChanged(v.content, versions?.[i + 1]?.content ?? {})}</span>
                      </span>
                      {i > 0 && (
                        <button type="button" className="btn ghost" onClick={() => restore(v.content, fmt(v.publishedAt))}>
                          <RotateCcw size={18} strokeWidth={1.75} aria-hidden /> Load
                        </button>
                      )}
                    </li>
                  ))}
                  <li>
                    <span>
                      <strong>Original site</strong>
                      <span className="edit-sec-count">Before any edits</span>
                    </span>
                    <button type="button" className="btn ghost" onClick={() => restore({}, "the original site")}>
                      <RotateCcw size={18} strokeWidth={1.75} aria-hidden /> Load
                    </button>
                  </li>
                </ul>
              </div>
            </details>
            {revision && (
              <>
                {/* Revision tools: input for Matt, never a change to the live site. */}
                <details className="edit-sec" data-tour="look" onToggle={(e) => onSection(e.currentTarget, sections[0]?.anchor ?? "top")}>
                  <summary>
                    <Palette size={22} strokeWidth={1.75} aria-hidden />
                    <span className="edit-sec-title">Fonts + colors</span>
                    <span className="edit-sec-count">Try a look</span>
                    <ChevronDown size={20} strokeWidth={1.75} className="edit-chev" aria-hidden />
                  </summary>
                  <div className="edit-sec-body">
                    <LookPicker config={revision} editKey={key} getFrame={getFrame} onRelock={relock} onPreview={() => (isPhone() ? setTab("preview") : scrollTo(sections[0]?.anchor ?? "top"))} />
                  </div>
                </details>
                <details className="edit-sec" data-tour="ask" onToggle={(e) => onSection(e.currentTarget)}>
                  <summary>
                    <MessageSquarePlus size={22} strokeWidth={1.75} aria-hidden />
                    <span className="edit-sec-title">Ask for a change</span>
                    <span className="edit-sec-count">Matt does it</span>
                    <ChevronDown size={20} strokeWidth={1.75} className="edit-chev" aria-hidden />
                  </summary>
                  <div className="edit-sec-body">
                    <RevisionForm config={revision} editKey={key} onRelock={relock} />
                  </div>
                </details>
                {revision.showUpgrades !== false && (
                  <details className="edit-sec" data-tour="more" onToggle={(e) => onSection(e.currentTarget)}>
                    <summary>
                      <Lock size={22} strokeWidth={1.75} aria-hidden />
                      <span className="edit-sec-title">More features</span>
                      <span className="edit-sec-count">See what&apos;s next</span>
                      <ChevronDown size={20} strokeWidth={1.75} className="edit-chev" aria-hidden />
                    </summary>
                    <div className="edit-sec-body">
                      <FeatureTeaser config={revision} />
                    </div>
                  </details>
                )}
              </>
            )}
              </div>
            </>
          )}
        </aside>
        <iframe ref={preview} data-tour="preview" className="edit-preview" src={liveUrl} title="Live preview of your site" />
      </div>

      {unlocked && (
        <nav className="edit-tabbar" aria-label="Editor">
          <button type="button" className={`edit-tab${tab === "edit" ? " on" : ""}`} aria-pressed={tab === "edit"} onClick={() => setTab("edit")}>
            <PenLine size={24} strokeWidth={1.75} aria-hidden /> Edit
          </button>
          <button type="button" className={`edit-tab${tab === "preview" ? " on" : ""}`} aria-pressed={tab === "preview"} data-tour="preview-tab" onClick={() => setTab("preview")}>
            <Eye size={24} strokeWidth={1.75} aria-hidden /> Preview
            {changeCount > 0 && <i className="edit-dot" aria-hidden />}
          </button>
          <span className="edit-tab-publish">
            {publishBtn}
            {changeCount > 0 && <span className="edit-tab-count" aria-label={`${changeCount} changes not live yet`}>{changeCount}</span>}
          </span>
        </nav>
      )}

      {confirm && (
        <div className="edit-sheet-back" onClick={() => setConfirm(null)}>
          <div className="edit-sheet" role="alertdialog" aria-modal="true" aria-labelledby="edit-sheet-title" aria-describedby="edit-sheet-body" onClick={(e) => e.stopPropagation()} onKeyDown={(e) => { if (e.key === "Escape") setConfirm(null); }}>
            <h2 id="edit-sheet-title">{confirm.title}</h2>
            <p id="edit-sheet-body">{confirm.body}</p>
            <div className="edit-row">
              <button className="btn" type="button" autoFocus onClick={() => setConfirm(null)}>{confirm.no}</button>
              <button className="btn ghost" type="button" onClick={() => { const c = confirm; setConfirm(null); c.onYes(); }}>{confirm.yes}</button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`edit-toast ${toast.kind}`} role={toast.kind === "err" ? "alert" : "status"} aria-live="polite">
          {toast.kind === "ok" && <Check size={20} strokeWidth={2} aria-hidden />}
          <span>{toast.msg}</span>
          {toast.action && <button type="button" className="btn ghost" onClick={toast.action.run}>{toast.action.label}</button>}
          {toast.retry && <button type="button" className="btn ghost" onClick={() => { setToast(null); toast.retry?.(); }}><RotateCcw size={16} strokeWidth={1.75} aria-hidden /> Try again</button>}
          {toast.kind !== "busy" && <button type="button" className="edit-toast-x" aria-label="Dismiss" onClick={() => setToast(null)}>×</button>}
        </div>
      )}
    </div>
  );
}

function fmt(iso: string) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  const time = d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" }).toLowerCase();
  const day = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const ago = Math.round((day(new Date()) - day(d)) / 86400000);
  if (ago === 0) return `Today ${time}`;
  if (ago === 1) return `Yesterday ${time}`;
  return `${d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}, ${time}`;
}
