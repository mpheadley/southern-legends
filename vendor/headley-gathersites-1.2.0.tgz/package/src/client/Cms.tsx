"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
  type CSSProperties,
  type ElementType,
  type FocusEvent,
  type KeyboardEvent,
} from "react";
import { RESTORE_PATH } from "../types";

/**
 * GatherSites CMS store.
 * - Published content is global: fetched from /api/cms on load, everyone sees it.
 * - Edits are local drafts (localStorage) for instant preview; the /edit preview iframe
 *   re-reads them through the storage event.
 * - publish(editKey) pushes the draft to the server (owner-gated) → goes live.
 * Nothing in this file publishes on its own. Only the editor's Publish button calls publish().
 */

const DEFAULT_STORE_KEY = "gathersites-draft";
type Store = Record<string, unknown>;

function getPath(obj: unknown, path: string): unknown {
  return path.split(".").reduce<unknown>((a, k) => (a && typeof a === "object" ? (a as Record<string, unknown>)[k] : undefined), obj);
}
function setPath(obj: Store, path: string, value: unknown): Store {
  const keys = path.split(".");
  const next: Store = { ...obj };
  let cur: Record<string, unknown> = next;
  for (let i = 0; i < keys.length - 1; i++) {
    cur[keys[i]] = typeof cur[keys[i]] === "object" && cur[keys[i]] ? { ...(cur[keys[i]] as object) } : {};
    cur = cur[keys[i]] as Record<string, unknown>;
  }
  cur[keys[keys.length - 1]] = value;
  return next;
}
function deepMerge(a: Store, b: Store): Store {
  const out: Store = { ...a };
  for (const k of Object.keys(b)) {
    const av = out[k], bv = b[k];
    out[k] = av && bv && typeof av === "object" && typeof bv === "object" && !Array.isArray(bv)
      ? deepMerge(av as Store, bv as Store) : bv;
  }
  return out;
}

export type CmsApi = {
  store: Store;
  loaded: boolean;
  editing: boolean;
  setEditing: (on: boolean) => void;
  /** Built-in copy per field path (from the site's content config). */
  defaults: Record<string, string>;
  get: (path: string) => unknown;
  setField: (path: string, value: string) => void;
  setValue: (path: string, value: unknown) => void;
  setImage: (key: string, url: string) => void;
  uploadImage: (dataUrl: string, editKey: string) => Promise<string | null>;
  publish: (editKey: string) => Promise<{ ok: boolean; error?: string }>;
  reset: () => void;
  undo: () => void;
  canUndo: boolean;
  /** The field the next Undo will put back ("__restore" = a loaded version), or null. */
  undoPath: string | null;
  /** Load a whole published version (or {} = the original site) into the draft. */
  replaceAll: (content: Store) => void;
  /** True when there are changes not yet published (works even where localStorage is blocked). */
  dirty: boolean;
  /** True when this one field/photo differs from what's live (empty and missing count as the same). */
  isDirty: (path: string) => boolean;
};

const CmsCtx = createContext<CmsApi>({
  store: {}, loaded: false, editing: false, setEditing: () => {}, defaults: {},
  get: () => undefined, setField: () => {}, setValue: () => {}, setImage: () => {},
  uploadImage: async () => null, publish: async () => ({ ok: false }), reset: () => {},
  undo: () => {}, canUndo: false, undoPath: null, replaceAll: () => {}, dirty: false, isDirty: () => false,
});

const norm = (v: unknown) => (typeof v === "string" ? v : v == null ? "" : JSON.stringify(v));

export function CmsProvider({
  children,
  defaults = {},
  storageKey = DEFAULT_STORE_KEY,
}: {
  children: ReactNode;
  /** Built-in copy per field path; `textDefaults(SECTIONS)` from the site's content file. */
  defaults?: Record<string, string>;
  /** localStorage key for the draft. Keep a site's existing key when migrating so saved drafts survive. */
  storageKey?: string;
}) {
  // Undo history lives next to the draft, per tab (sessionStorage): "<storageKey>History".
  const historyKey = `${storageKey}History`;
  const [server, setServer] = useState<Store>({});
  const [draft, setDraft] = useState<Store>({});
  const [loaded, setLoaded] = useState(false);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    const readDraft = () => {
      try { setDraft(JSON.parse(localStorage.getItem(storageKey) || "{}") || {}); } catch {}
    };
    readDraft();
    fetch("/api/cms")
      .then((r) => r.json())
      .then((j) => setServer(j?.content && typeof j.content === "object" ? j.content : {}))
      .catch(() => {})
      .finally(() => setLoaded(true));
    // Live sync: the split-screen preview (iframe) re-reads when the editor writes.
    const onStorage = (e: StorageEvent) => { if (e.key === storageKey) readDraft(); };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [storageKey]);

  // A restored version replaces everything (marked __replace) instead of layering on what's live.
  const effective = (srv: Store, d: Store): Store => {
    if (!d.__replace) return deepMerge(srv, d);
    const { __replace, ...rest } = d;
    void __replace;
    return rest;
  };
  const store = effective(server, draft);

  const persistDraft = useCallback((d: Store) => {
    setDraft(d);
    try { localStorage.setItem(storageKey, JSON.stringify(d)); } catch {}
  }, [storageKey]);

  // Undo history: one snapshot per change, tagged with the field it was for. A burst of
  // typing in the same field (no pause over 1.2s) counts as one change, so Undo doesn't
  // go letter by letter. Kept in sessionStorage so a refresh doesn't grey out Undo.
  const history = useRef<{ draft: Store; path: string }[]>([]);
  const lastEdit = useRef<{ path: string; t: number } | null>(null);
  const [undoCount, setUndoCount] = useState(0);
  const saveHistory = useCallback(() => {
    setUndoCount(history.current.length);
    try { sessionStorage.setItem(historyKey, JSON.stringify(history.current)); } catch {}
  }, [historyKey]);
  useEffect(() => {
    try {
      const h = JSON.parse(sessionStorage.getItem(historyKey) || "[]");
      if (Array.isArray(h)) { history.current = h; setUndoCount(h.length); }
    } catch {}
  }, [historyKey]);
  const remember = useCallback((path: string) => {
    const now = Date.now();
    const l = lastEdit.current;
    if (!l || l.path !== path || now - l.t > 1200) {
      history.current.push({ draft, path });
      if (history.current.length > 100) history.current.shift();
      saveHistory();
    }
    lastEdit.current = { path, t: now };
  }, [draft, saveHistory]);
  const clearHistory = useCallback(() => {
    history.current = [];
    lastEdit.current = null;
    saveHistory();
  }, [saveHistory]);
  const undo = useCallback(() => {
    const prev = history.current.pop();
    if (prev === undefined) return;
    lastEdit.current = null;
    saveHistory();
    persistDraft(prev.draft);
  }, [persistDraft, saveHistory]);

  const setField = useCallback((path: string, value: string) => { remember(path); persistDraft(setPath(draft, path, value)); }, [draft, persistDraft, remember]);
  const setValue = useCallback((path: string, value: unknown) => { remember(path); persistDraft(setPath(draft, path, value)); }, [draft, persistDraft, remember]);
  const setImage = useCallback((key: string, url: string) => { remember(`images.${key}`); lastEdit.current = null; persistDraft(setPath(draft, `images.${key}`, url)); }, [draft, persistDraft, remember]);
  const get = useCallback((path: string) => getPath(effective(server, draft), path), [server, draft]);
  const isDirty = useCallback((path: string) => norm(getPath(effective(server, draft), path)) !== norm(getPath(server, path)), [server, draft]);

  const uploadImage = useCallback(async (dataUrl: string, editKey: string): Promise<string | null> => {
    try {
      const r = await fetch("/api/cms/upload", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ dataUrl, editKey }) });
      const j = await r.json();
      return r.ok ? j.url : null;
    } catch { return null; }
  }, []);

  const publish = useCallback(async (editKey: string): Promise<{ ok: boolean; error?: string }> => {
    const merged = effective(server, draft);
    try {
      // Upload any instant-preview (data-URL) photos to the server first.
      const images = merged.images as Record<string, string> | undefined;
      if (images) {
        for (const k of Object.keys(images)) {
          const v = images[k];
          if (typeof v === "string" && v.startsWith("data:image/")) {
            const up = await fetch("/api/cms/upload", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ dataUrl: v, editKey }) });
            const uj = await up.json();
            if (!up.ok) return { ok: false, error: uj.error || "photo upload failed" };
            images[k] = uj.url;
          }
        }
      }
      const r = await fetch("/api/cms", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: merged, editKey }) });
      const j = await r.json();
      if (!r.ok) return { ok: false, error: j.error || "publish failed" };
      setServer(merged);
      persistDraft({});
      clearHistory();
      return { ok: true };
    } catch (e) { return { ok: false, error: String(e) }; }
  }, [server, draft, persistDraft, clearHistory]);

  const reset = useCallback(() => { persistDraft({}); clearHistory(); }, [persistDraft, clearHistory]);
  const replaceAll = useCallback((content: Store) => {
    remember(RESTORE_PATH);
    lastEdit.current = null;
    persistDraft({ ...content, __replace: true });
  }, [persistDraft, remember]);

  return <CmsCtx.Provider value={{ store, loaded, editing, setEditing, defaults, get, setField, setValue, setImage, uploadImage, publish, reset, undo, canUndo: undoCount > 0, undoPath: undoCount > 0 ? history.current[history.current.length - 1]?.path ?? null : null, replaceAll, dirty: Object.keys(draft).length > 0, isDirty }}>{children}</CmsCtx.Provider>;
}

export function useCms() { return useContext(CmsCtx); }

/**
 * Text that can be edited in place when `editing` is on. Edits land in the local draft only;
 * this component never publishes (publishing is the editor's Publish button, nothing else).
 */
export function Editable({ path, children, as = "span", className, style }: { path: string; children: ReactNode; as?: ElementType; className?: string; style?: CSSProperties }) {
  const { get, editing, setField } = useCms();
  const v = get(path);
  const Tag = as;
  const text = typeof v === "string" && v.trim() ? v : children;

  if (!editing) return <Tag className={className} style={style}>{text}</Tag>;

  // In edit mode: click any highlighted element to change its text inline.
  const editStyle: CSSProperties = {
    ...style,
    outline: "1.5px dashed var(--gm-accent, #A84F1E)",
    outlineOffset: "3px",
    borderRadius: "3px",
    cursor: "text",
    transition: "background 120ms ease",
  };
  return (
    <Tag
      className={className}
      style={editStyle}
      contentEditable
      suppressContentEditableWarning
      data-cms-path={path}
      title={`Editing: ${path}`}
      onBlur={(e: FocusEvent<HTMLElement>) => {
        const next = e.currentTarget.innerText.trim();
        const current = typeof v === "string" ? v : (typeof children === "string" ? children : "");
        if (next && next !== current) setField(path, next);
      }}
      onKeyDown={(e: KeyboardEvent<HTMLElement>) => {
        // Enter commits (blur) unless Shift is held for a soft line break.
        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); (e.currentTarget as HTMLElement).blur(); }
        if (e.key === "Escape") { (e.currentTarget as HTMLElement).blur(); }
      }}
    >
      {text}
    </Tag>
  );
}

/** Editable text with the site's built-in copy as the fallback: published words, else `defaults[k]`, else `fallback`. */
export function T({
  k,
  as = "span",
  className,
  style,
  fallback,
}: {
  k: string;
  as?: ElementType;
  className?: string;
  style?: CSSProperties;
  fallback?: ReactNode;
}) {
  const { defaults } = useCms();
  return (
    <Editable path={k} as={as} className={className} style={style}>
      {defaults[k] || fallback}
    </Editable>
  );
}
