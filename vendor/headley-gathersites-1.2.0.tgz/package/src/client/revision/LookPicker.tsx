"use client";

// Font + color picker. Previews LIVE inside the editor's preview frame and nowhere else:
// it injects one <style> into the iframe document, never touches the CMS store, never publishes.
// "Send my pick" becomes a revision request that Matt reviews and applies by hand.
//
// Built from two tools that already existed:
//  - nextjs-starter-kit/font-picker-template.html (Sat Co's Charmly font candidates, rendered on real words)
//  - gather/packages/ui/src/desk/ThemePicker.tsx (labeled rows of toggle buttons, the active one marked)
import { useCallback, useEffect, useState } from "react";
import { Check, Eye, RotateCcw, Send } from "lucide-react";
import { sendRevision, type FontPair, type LookOption, type RevisionSiteConfig } from "../../revision";

const STYLE_ID = "gs-look-preview";
const LINK_ID = "gs-look-fonts";

function fontsHref(families: string[]) {
  const uniq = [...new Set(families)];
  if (!uniq.length) return "";
  return `https://fonts.googleapis.com/css2?${uniq.map((f) => `family=${f}`).join("&")}&display=swap`;
}

function overrideCss(cfg: RevisionSiteConfig, font: FontPair, look: LookOption) {
  const v = cfg.cssVars;
  const set = (names: string[] | undefined, val: string | undefined) => (val && names ? names.map((n) => `${n}:${val} !important;`).join("") : "");
  const light = set(v.display, font.display) + set(v.body, font.body) + set(v.accent, look.accent) + set(v.accentHover, look.accentHover);
  const dark = set(v.accent, look.accentDark);
  if (!light && !dark) return "";
  return (
    `:root{${light}}` +
    (dark ? `@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){${dark}}}:root[data-theme="dark"]{${dark}}` : "")
  );
}

function ensureLink(doc: Document, href: string) {
  let link = doc.getElementById(LINK_ID) as HTMLLinkElement | null;
  if (!href) return link?.remove();
  if (!link) {
    link = doc.createElement("link");
    link.id = LINK_ID;
    link.rel = "stylesheet";
    doc.head.appendChild(link);
  }
  if (link.href !== href) link.href = href;
}

export default function LookPicker({
  config,
  editKey,
  getFrame,
  onPreview,
  onRelock,
}: {
  config: RevisionSiteConfig;
  editKey: string;
  getFrame: () => HTMLIFrameElement | null;
  /** Show the preview (phones switch to the Preview tab). */
  onPreview?: () => void;
  /** Server said the password is wrong. */
  onRelock?: () => void;
}) {
  const [fontId, setFontId] = useState(config.fonts[0]?.id ?? "");
  const [lookId, setLookId] = useState(config.looks[0]?.id ?? "");
  const [note, setNote] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");

  const font = config.fonts.find((f) => f.id === fontId) ?? config.fonts[0];
  const look = config.looks.find((l) => l.id === lookId) ?? config.looks[0];
  const isCurrent = font === config.fonts[0] && look === config.looks[0];

  // The editor itself loads every candidate once so each button shows its own font.
  useEffect(() => {
    ensureLink(document, fontsHref(config.fonts.flatMap((f) => f.google ?? [])));
  }, [config.fonts]);

  const apply = useCallback(() => {
    let doc: Document | null | undefined;
    try { doc = getFrame()?.contentDocument; } catch { return; }
    if (!doc?.head) return;
    ensureLink(doc, fontsHref(font.google ?? []));
    const css = overrideCss(config, font, look);
    let st = doc.getElementById(STYLE_ID);
    if (!css) return st?.remove();
    if (!st) {
      st = doc.createElement("style");
      st.id = STYLE_ID;
      doc.head.appendChild(st);
    }
    st.textContent = css;
  }, [config, font, look, getFrame]);

  // Apply now, and again whenever the preview reloads (navigation, publish).
  useEffect(() => {
    apply();
    const frame = getFrame();
    frame?.addEventListener("load", apply);
    return () => frame?.removeEventListener("load", apply);
  }, [apply, getFrame]);

  // Leaving the editor (log out, unmount) clears the preview-only override.
  useEffect(() => () => {
    try {
      const doc = getFrame()?.contentDocument;
      doc?.getElementById(STYLE_ID)?.remove();
    } catch {}
  }, [getFrame]);

  async function send() {
    setState("sending");
    const r = await sendRevision(editKey, {
      kind: "look",
      font: `${font.name}${font === config.fonts[0] ? " (keep current)" : ""}`,
      colors: `${look.name}${look === config.looks[0] ? " (keep current)" : ""}`,
      why: note.trim() || undefined,
    });
    if (r.status === 403) return onRelock?.();
    setState(r.ok ? "sent" : "error");
  }

  return (
    <div className="rv">
      <p className="rv-note">
        <Eye size={20} strokeWidth={1.75} aria-hidden /> Tap a choice and watch the preview change. Only you see it. Your live site stays the same until Matt makes the change.
      </p>

      <fieldset className="rv-group">
        <legend className="rv-legend">Fonts</legend>
        <div className="rv-options">
          {config.fonts.map((f, i) => (
            <button
              key={f.id}
              type="button"
              className={`rv-opt${f.id === font.id ? " is-on" : ""}`}
              aria-pressed={f.id === font.id}
              onClick={() => { setFontId(f.id); setState("idle"); }}
            >
              <span className="rv-sample" style={{ fontFamily: f.display ?? "var(--font-display)" }}>Aa</span>
              <span className="rv-opt-text">
                <span className="rv-opt-name" style={{ fontFamily: f.display ?? "var(--font-display)" }}>{f.name}</span>
                <span className="rv-opt-feel">{i === 0 ? "What you have now. " : ""}{f.feel}</span>
              </span>
              {f.id === font.id && <Check className="rv-tick" size={22} strokeWidth={2.25} aria-hidden />}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="rv-group">
        <legend className="rv-legend">Colors</legend>
        <div className="rv-options">
          {config.looks.map((l, i) => (
            <button
              key={l.id}
              type="button"
              className={`rv-opt${l.id === look.id ? " is-on" : ""}`}
              aria-pressed={l.id === look.id}
              onClick={() => { setLookId(l.id); setState("idle"); }}
            >
              <span className="rv-swatch" aria-hidden>
                {l.swatch.map((c) => <i key={c} style={{ background: c }} />)}
              </span>
              <span className="rv-opt-text">
                <span className="rv-opt-name">{l.name}</span>
                <span className="rv-opt-feel">{i === 0 ? "What you have now. " : ""}{l.feel}</span>
              </span>
              {l.id === look.id && <Check className="rv-tick" size={22} strokeWidth={2.25} aria-hidden />}
            </button>
          ))}
        </div>
      </fieldset>

      <div className="edit-row rv-row">
        {onPreview && (
          <button type="button" className="btn ghost" onClick={onPreview}><Eye size={18} strokeWidth={1.75} aria-hidden /> See it</button>
        )}
        {!isCurrent && (
          <button type="button" className="btn ghost" onClick={() => { setFontId(config.fonts[0].id); setLookId(config.looks[0].id); setState("idle"); }}>
            <RotateCcw size={18} strokeWidth={1.75} aria-hidden /> Back to what I have
          </button>
        )}
      </div>

      <label className="edit-field">
        <span className="edit-label">Anything else about the look? (optional)</span>
        <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Example: I like these fonts, but the buttons feel too dark." />
      </label>

      <div className="rv-pick" aria-live="polite">
        <span><b>Your pick:</b> {font.name} · {look.name}</span>
      </div>

      {state === "sent" ? (
        <p className="rv-done" role="status">
          <Check size={22} strokeWidth={2.25} aria-hidden /> Sent to Matt. He looks it over and makes the change himself. You can keep trying other looks.
        </p>
      ) : (
        <button type="button" className="btn rv-send" onClick={send} disabled={state === "sending"}>
          <Send size={18} strokeWidth={1.75} aria-hidden /> {state === "sending" ? "Sending…" : "Send my pick to Matt"}
        </button>
      )}
      {state === "error" && (
        <p className="edit-inline-err" role="alert">That didn&apos;t send. Your pick is still here. Check your internet and try again.</p>
      )}
    </div>
  );
}
