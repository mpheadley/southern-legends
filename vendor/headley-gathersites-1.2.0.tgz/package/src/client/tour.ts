import { driver } from "driver.js";
import "driver.js/dist/driver.css";

const HAND_SVG = `<svg viewBox="0 0 24 24" width="44" height="44" fill="#f0ede8" stroke="#A84F1E" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M22 14a8 8 0 0 1-8 8"/><path d="M18 11v-1a2 2 0 0 0-2-2a2 2 0 0 0-2 2"/><path d="M14 10V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1"/><path d="M10 9.5V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v10"/><path d="M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/></svg>`;

/** The five-stop editor tour (sections → photo → words → preview → publish) with the pointing hand. */
export function runEditorTour(tourDoneKey: string) {
  document.querySelector<HTMLDetailsElement>('[data-tour="cover"]')?.setAttribute("open", "");
  // Some targets render twice (header on desktop, bottom bar on phones); take whichever is on screen.
  const visible = (sel: string) => {
    for (const el of document.querySelectorAll<HTMLElement>(sel)) if (el.offsetParent !== null) return el;
    return null;
  };
  const steps = [
    { sel: '[data-tour="sections"]', title: "Your sections", description: "Each one matches a part of your home page, top to bottom. Tap one to open it." },
    { sel: '[data-tour="cover"] .edit-drop', title: "Swap a photo", description: "Tap any photo box and pick a photo. Big phone photos are fine; they get resized for you." },
    { sel: '[data-tour="cover"] .edit-field input, [data-tour="cover"] .edit-field textarea', title: "Change the words", description: "Type right in the box. The preview updates as you go." },
    { sel: '[data-tour="preview"], [data-tour="preview-tab"]', title: "Your preview", description: "This is how your site will look. On a phone, tap Preview to see it. Nothing is public until you publish." },
    { sel: '[data-tour="publish"]', title: "Publish", description: "When it looks right, hit Publish and it goes live. Undo and Published versions are your safety net." },
  ].flatMap(({ sel, title, description }) => {
    const el = visible(sel);
    return el ? [{ element: el as Element, popover: { title, description } }] : [];
  });
  if (!steps.length) return;
  // One tour at a time: a second start (double tap, re-render) would leave an orphan hand behind.
  activeTour?.destroy();
  document.querySelectorAll(".gm-tour-hand").forEach((h) => h.remove());
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Animated pointing hand next to whatever the tour is highlighting.
  const hand = document.createElement("div");
  hand.className = "gm-tour-hand";
  hand.setAttribute("aria-hidden", "true");
  hand.innerHTML = HAND_SVG;
  document.body.appendChild(hand);
  // Finger sits at the item's bottom-right corner pointing up into it; for big areas (panel, preview) it points up from inside.
  const pointAt = (el?: Element) => {
    if (!el) { hand.style.opacity = "0"; return; }
    const r = el.getBoundingClientRect();
    const big = r.width > 420 || r.right > window.innerWidth - 80;
    const left = big ? r.left + Math.min(r.width / 2, 260) : r.right - 26;
    const top = big ? r.top + 60 : r.bottom - 30;
    hand.style.setProperty("--rot", big ? "0deg" : "-20deg");
    hand.style.setProperty("--dx", big ? "0px" : "-5px");
    hand.style.setProperty("--dy", "-8px");
    hand.style.left = `${Math.min(window.innerWidth - 56, Math.max(8, left))}px`;
    hand.style.top = `${Math.min(window.innerHeight - 56, Math.max(8, top))}px`;
    hand.style.opacity = "1";
  };

  const tour = driver({
    showProgress: true,
    animate: !reduce,
    smoothScroll: !reduce,
    allowClose: true,
    popoverClass: "gm-tour",
    nextBtnText: "Next",
    prevBtnText: "Back",
    doneBtnText: "Got it",
    steps,
    onHighlighted: (el) => pointAt(el),
    onPopoverRender: (popover) => {
      const exit = document.createElement("button");
      exit.type = "button";
      exit.className = "gm-tour-exit";
      exit.textContent = "Exit tour";
      exit.onclick = () => { cleanup(); tour.destroy(); };
      popover.footerButtons.prepend(exit);
    },
    // driver.js skips onDestroyed when the tour closes mid-transition, so every close path
    // (Got it, X, Esc, overlay, Exit tour) cleans up here first.
    onDestroyStarted: () => { cleanup(); tour.destroy(); },
    onDestroyed: cleanup,
  });
  function cleanup() {
    document.querySelectorAll(".gm-tour-hand").forEach((h) => h.remove());
    if (activeTour === tour) activeTour = null;
    try { localStorage.setItem(tourDoneKey, "1"); } catch {}
  }
  activeTour = tour;
  tour.drive();
}

let activeTour: ReturnType<typeof driver> | null = null;
